from fractions import Fraction as F
from pathlib import Path
import sys,json
ROOT=Path('/mnt/data/phase_c1_independent_audit_20260823/run_copy'); sys.path.insert(0,str(ROOT))
from reach_engine import Circle,ReachEngine,Status

def account(r):
    assert r.accounting_ok and r.processing_accounting_ok and r.unresolved_accounting_ok
    if r.status not in (Status.INPUT_INVALID, Status.CURVATURE_FAIL):
        assert r.initial_pair_boxes+r.local_pruned==r.all_patch_pairs
    if r.status is Status.VALID:
        assert r.unresolved_boxes==0 and r.queued_boxes_at_exit==0

def ref_collinear(cs):
    ans=min(c.radius for c in cs)
    for i,a in enumerate(cs):
        for b in cs[i+1:]:
            d=abs(a.cx-b.cx); s=a.radius+b.radius; q=abs(a.radius-b.radius)
            if d>s: gap=d-s
            elif d<q: gap=q-d
            else: raise AssertionError('invalid reference link')
            ans=min(ans,gap/F(2))
    return ans

def unit(q,t):
    d=1+t*t; x=(1-t*t)/d; y=2*t/d
    return ((x,y),(-y,x),(-x,-y),(y,-x))[q%4]
rows=[]
def go(name,cs,ref,r0,p,depth,boxes,oracle):
    r=ReachEngine(p,depth,boxes).certify(cs,r0); account(r)
    if oracle=='valid': ok=r.status is Status.VALID
    elif oracle=='not_valid': ok=r.status is not Status.VALID
    elif oracle=='curvature': ok=r.status is Status.CURVATURE_FAIL
    else: ok=r.status in (Status.VALID,Status.UNKNOWN)
    fv=(r0>ref and r.status is Status.VALID)
    row={'id':name,'p':p,'true_reach':str(ref),'r0':str(r0),'status':r.status.name,'boxes':r.interval_boxes,'max_depth_seen':r.max_depth_seen,'unresolved':r.unresolved_boxes,'false_valid':fv,'passed':ok and not fv}
    rows.append(row); print(json.dumps(row),flush=True); assert row['passed'],row

# Five circles with a hidden 1/100 boundary gap.
hidden=[Circle(0,0,2),Circle(20,0,3),Circle(F(2401,100),0,1),Circle(50,0,5),Circle(70,0,2)]
hr=ref_collinear(hidden); assert hr==F(1,200)
for p in (2,4,7):
    go(f'hidden_p{p}_below',hidden,hr,F(9,2000),p,35,600000,'valid')
    go(f'hidden_p{p}_above',hidden,hr,F(11,2000),p,8,180000,'not_valid')

# Concentric equality/nonisolated family and strict sides.
ann=[Circle(0,0,2),Circle(0,0,5)]; ar=F(3,2)
for p in (2,4,7):
    go(f'annulus_p{p}_below',ann,ar,F(7,5),p,20,400000,'valid')
    go(f'annulus_p{p}_above',ann,ar,F(8,5),p,6,120000,'not_valid')
go('annulus_p4_equal',ann,ar,ar,4,6,120000,'may')

# Four nested layers.
multi=[Circle(0,0,2),Circle(0,0,5),Circle(0,0,9),Circle(0,0,14)]; mr=F(3,2)
for p in (2,5):
    go(f'multinested_p{p}_below',multi,mr,F(7,5),p,20,500000,'valid')
    go(f'multinested_p{p}_above',multi,mr,F(8,5),p,5,120000,'not_valid')

# Off-centre nested closest pair aligned with a rational seam.
ux,uy=unit(1,F(2,5)); off=[Circle(0,0,10),Circle(F(11,2)*ux,F(11,2)*uy,3)]; rr=F(3,4)
for p in (3,5):
    go(f'offcenter_p{p}_below',off,rr,F(7,10),p,25,350000,'valid')
    go(f'offcenter_p{p}_above',off,rr,F(4,5),p,8,120000,'not_valid')

# Nested stack plus external short gap.
mixed=[Circle(0,0,2),Circle(0,0,5),Circle(0,0,9),Circle(0,0,14),Circle(18,0,3)]; xr=ref_collinear(mixed); assert xr==F(1,2)
for p in (2,4):
    go(f'mixed_p{p}_below',mixed,xr,F(2,5),p,20,500000,'valid')
    go(f'mixed_p{p}_above',mixed,xr,F(3,5),p,7,150000,'not_valid')

# Huge exact fields/translation.
T=F(10**100+123456789,10**50+7); R1=F(10**60+1,10**60); R2=F(2*10**60+3,10**60); gap=F(10**80+7,10**80+9)
large=[Circle(T,-T,R1),Circle(T+R1+R2+gap,-T,R2)]; lr=gap/F(2)
go('huge_external_below',large,lr,lr-F(1,1000),4,28,300000,'valid')
go('huge_external_above',large,lr,lr+F(1,1000),4,8,100000,'not_valid')

# Tiny exact gap denominator.
tg=F(1,10**30); tiny=[Circle(0,0,2),Circle(4+tg,0,2)]; tr=tg/F(2)
go('tiny_gap_below',tiny,tr,tr-F(1,10**32),4,16,100000,'may')
go('tiny_gap_equal',tiny,tr,tr,4,8,100000,'may')
go('tiny_gap_above',tiny,tr,tr+F(1,10**32),4,8,100000,'not_valid')

# Huge single-circle radius: local curvature and antipodal equality.
Rb=F(10**80+3,10**40+7); single=[Circle(T,T,Rb)]
for p in (2,7):
    go(f'huge_single_p{p}_below',single,Rb,Rb/F(2),p,20,250000,'valid')
    go(f'huge_single_p{p}_equal',single,Rb,Rb,p,6,100000,'may')
    go(f'huge_single_p{p}_above',single,Rb,Rb+1,p,6,100000,'curvature')

summary={'total':len(rows),'false_valid':sum(r['false_valid'] for r in rows),'valid':sum(r['status']=='VALID' for r in rows),'unknown':sum(r['status']=='UNKNOWN' for r in rows),'curvature_fail':sum(r['status']=='CURVATURE_FAIL' for r in rows),'failures':[r for r in rows if not r['passed']]}
Path('/mnt/data/phase_c1_independent_audit_20260823/final_structural_stress_results.json').write_text(json.dumps({'summary':summary,'rows':rows},indent=2))
print('SUMMARY',json.dumps(summary),flush=True)
