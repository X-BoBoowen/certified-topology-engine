from __future__ import annotations
from fractions import Fraction as F
from pathlib import Path
import json, sys
ROOT=Path('/mnt/data/phase_c1_independent_audit_20260823/run_copy')
sys.path.insert(0,str(ROOT))
from reach_engine import Circle, ReachEngine, Status

def unit(q:int,t:F):
    d=1+t*t
    x=(1-t*t)/d; y=2*t/d
    q%=4
    return ((x,y),(-y,x),(-x,-y),(y,-x))[q]

def scale(v,a): return v[0]*a,v[1]*a

def check_accounting(r):
    assert r.accounting_ok and r.processing_accounting_ok and r.unresolved_accounting_ok
    assert r.initial_pair_boxes+r.local_pruned==r.all_patch_pairs
    if r.status is Status.VALID:
        assert r.unresolved_boxes==0 and r.queued_boxes_at_exit==0

rows=[]
reach=F(7,10); gap=2*reach; R=F(2)
near=F(1,10**20); comfortable=F(1,1000)
for p,j,q in [(2,1,0),(3,1,1),(4,2,2),(5,2,3),(7,3,0)]:
    t=F(j,p); u=unit(q,t); center=scale(u,2*R+gap)
    circles=[Circle(F(0),F(0),R),Circle(center[0],center[1],R)]
    engine=ReachEngine(pieces_per_quarter=p,max_depth=130,max_boxes=2_000_000)
    cases=[
      ('comfortable_below',reach-comfortable,'must_valid'),
      ('near_below',reach-near,'may_abstain'),
      ('equal',reach,'may_abstain'),
      ('near_above',reach+near,'must_not_valid'),
      ('comfortable_above',reach+comfortable,'must_not_valid'),
    ]
    for side,r0,oracle in cases:
        r=engine.certify(circles,r0); check_accounting(r)
        if oracle=='must_valid': ok=r.status is Status.VALID
        elif oracle=='must_not_valid': ok=r.status is not Status.VALID
        else: ok=r.status in (Status.VALID,Status.UNKNOWN)
        false_valid=(r0>reach and r.status is Status.VALID)
        row={'id':f'seam_p{p}_q{q}_t{j}/{p}_{side}','p':p,'true_reach':str(reach),'r0':str(r0),'oracle':oracle,'status':r.status.name,'boxes':r.interval_boxes,'depth':r.max_depth_seen,'unresolved':r.unresolved_boxes,'false_valid':false_valid,'passed':ok and not false_valid}
        rows.append(row); print(json.dumps(row),flush=True); assert row['passed'],row
summary={'total':len(rows),'false_valid':sum(r['false_valid'] for r in rows),'near_below_unknown':sum(r['id'].endswith('near_below') and r['status']=='UNKNOWN' for r in rows),'failures':[r for r in rows if not r['passed']]}
Path('/mnt/data/phase_c1_independent_audit_20260823/geometry_near_threshold_results.json').write_text(json.dumps({'summary':summary,'rows':rows},indent=2))
print('SUMMARY',json.dumps(summary),flush=True)
