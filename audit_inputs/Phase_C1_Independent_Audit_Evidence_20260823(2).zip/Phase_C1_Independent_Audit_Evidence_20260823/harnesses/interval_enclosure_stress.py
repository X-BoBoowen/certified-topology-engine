from __future__ import annotations
from fractions import Fraction as F
from random import Random
from pathlib import Path
import json, sys
ROOT=Path('/mnt/data/phase_c1_independent_audit_20260823/run_copy')
sys.path.insert(0,str(ROOT))
from reach_engine import Circle, CirclePatch, Interval, bisect_interval_cover

rng=Random(91023817)

def base(t:F):
    d=1+t*t
    return (1-t*t)/d, 2*t/d

def base_tan(t:F):
    d=(1+t*t)**2
    return -4*t/d, 2*(1-t*t)/d

def rot(x:F,y:F,q:int):
    q%=4
    return ((x,y),(-y,x),(-x,-y),(y,-x))[q]

def pos(c:Circle,q:int,t:F):
    x,y=rot(*base(t),q)
    return c.cx+c.radius*x,c.cy+c.radius*y

def tan(c:Circle,q:int,t:F):
    x,y=rot(*base_tan(t),q)
    return c.radius*x,c.radius*y

def inside(x:F,I:Interval):
    return I.lo <= x <= I.hi

def rf(scale=50,den=97):
    return F(rng.randint(-scale*den,scale*den),rng.randint(1,den))

position_coords=tangent_coords=pair_quantities=partition_checks=0
# Moderate and deliberately large exact coefficients.
circle_pool=[]
for _ in range(40):
    circle_pool.append(Circle(rf(),rf(),F(rng.randint(1,300),rng.randint(1,97))))
N=10**80+123456789012345678901
D=10**40+13579
circle_pool += [
    Circle(F(N,D),F(-N+7,D),F(10**50+17,10**25+3)),
    Circle(F(-N,D),F(N-11,D),F(10**45+19,10**23+9)),
]

for k in range(6000):
    c=circle_pool[rng.randrange(len(circle_pool))]
    q=rng.randrange(4)
    a,b=sorted((F(rng.randrange(101),100),F(rng.randrange(101),100)))
    I=Interval(a,b)
    patch=CirclePatch(0,q,20,q,I,c)
    P=patch.position(I); T=patch.tangent(I)
    samples={a,b,(a+b)/2}
    for _ in range(3):
        lam=F(rng.randrange(101),100)
        samples.add(a+lam*(b-a))
    for t in samples:
        ep=pos(c,q,t); et=tan(c,q,t)
        assert inside(ep[0],P[0]) and inside(ep[1],P[1])
        assert inside(et[0],T[0]) and inside(et[1],T[1])
        position_coords += 2
        tangent_coords += 2

for k in range(6000):
    ca=circle_pool[rng.randrange(len(circle_pool))]
    cb=circle_pool[rng.randrange(len(circle_pool))]
    qa,qb=rng.randrange(4),rng.randrange(4)
    a0,a1=sorted((F(rng.randrange(101),100),F(rng.randrange(101),100)))
    b0,b1=sorted((F(rng.randrange(101),100),F(rng.randrange(101),100)))
    A=Interval(a0,a1); B=Interval(b0,b1)
    pa=CirclePatch(0,qa,20,qa,A,ca); pb=CirclePatch(1,qb,20,qb,B,cb)
    xa=pa.position(A); xb=pb.position(B)
    ch=(xa[0]-xb[0],xa[1]-xb[1])
    d2=ch[0].square()+ch[1].square()
    ta=pa.tangent(A); tb=pb.tangent(B)
    g1=ch[0]*ta[0]+ch[1]*ta[1]
    g2=ch[0]*tb[0]+ch[1]*tb[1]
    SA={a0,a1,(a0+a1)/2}; SB={b0,b1,(b0+b1)/2}
    for s in SA:
        for t in SB:
            epa=pos(ca,qa,s); epb=pos(cb,qb,t)
            eta=tan(ca,qa,s); etb=tan(cb,qb,t)
            ech=(epa[0]-epb[0],epa[1]-epb[1])
            ed2=ech[0]*ech[0]+ech[1]*ech[1]
            eg1=ech[0]*eta[0]+ech[1]*eta[1]
            eg2=ech[0]*etb[0]+ech[1]*etb[1]
            assert inside(ed2,d2)
            assert inside(eg1,g1)
            assert inside(eg2,g2)
            pair_quantities += 3

for _ in range(20000):
    a,b=sorted((rf(5,100),rf(5,100)))
    parent=Interval(a,b)
    left,right=bisect_interval_cover(parent)
    assert left.lo==parent.lo and right.hi==parent.hi
    assert left.hi==right.lo==parent.mid
    assert left.width+right.width==parent.width
    partition_checks += 1

summary={
    'position_coordinate_inclusions':position_coords,
    'tangent_coordinate_inclusions':tangent_coords,
    'd2_g1_g2_inclusions':pair_quantities,
    'bisection_cover_checks':partition_checks,
    'large_fraction_cases_included':True,
    'result':'PASS',
}
Path('/mnt/data/phase_c1_independent_audit_20260823/interval_enclosure_stress_results.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
