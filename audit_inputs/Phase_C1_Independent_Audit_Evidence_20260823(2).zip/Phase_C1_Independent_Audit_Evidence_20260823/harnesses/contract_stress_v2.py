from decimal import Decimal
from fractions import Fraction as F
from dataclasses import dataclass
from pathlib import Path
import json, sys
ROOT=Path('/mnt/data/phase_c1_independent_audit_20260823/run_copy')
sys.path.insert(0,str(ROOT))
from reach_engine import Circle, ReachEngine, Status
try:
    import numpy as np
except Exception:
    np=None

class FS(F): pass
class IS(int): pass
class Bomb:
    calls=0
    def boom(self,*a,**k):
        type(self).calls += 1
        raise AssertionError('numeric protocol invoked')
    __float__=__int__=__index__=__add__=__radd__=__sub__=__rsub__=__mul__=__rmul__=__truediv__=__rtruediv__=__lt__=__le__=__gt__=__ge__=boom
class CS(Circle): pass
@dataclass
class CircleLike:
    cx: object; cy: object; radius: object

def accounting(r):
    assert r.accounting_ok and r.processing_accounting_ok and r.unresolved_accounting_ok
    assert r.initial_pair_boxes + r.local_pruned == r.all_patch_pairs
    if r.status is Status.VALID:
        assert r.unresolved_boxes == 0 and r.queued_boxes_at_exit == 0

rows=[]
def rec(name,ok,**data):
    row={'name':name,'passed':bool(ok),**data}
    rows.append(row)
    print(json.dumps(row,default=str),flush=True)
    assert ok,name

unsupported=[('float',0.7),('Decimal',Decimal('0.7')),('boolT',True),('boolF',False),('str','7/10'),('bytes',b'7/10'),('complex',1+0j),('None',None),('FractionSubclass',FS(7,10)),('IntSubclass',IS(1)),('custom',Bomb())]
if np is not None:
    unsupported += [('np.float64',np.float64(.7)),('np.float32',np.float32(.7)),('np.int64',np.int64(1)),('np.uint64',np.uint64(1)),('np.bool_',np.bool_(True))]
base=Circle(F(0),F(0),F(3))
for label,v in unsupported:
    Bomb.calls=0
    r=ReachEngine().certify([base],v); accounting(r)
    rec('r0_'+label,r.status is Status.INPUT_INVALID and r.interval_boxes==0 and r.patch_count==0 and Bomb.calls==0,status=r.status.name)
for label,v in unsupported:
    for field in ('cx','cy','radius'):
        Bomb.calls=0
        kw={'cx':F(0),'cy':F(0),'radius':F(3)}; kw[field]=v
        r=ReachEngine().certify([Circle(**kw)],F(1)); accounting(r)
        rec(f'circle_{field}_{label}',r.status is Status.INPUT_INVALID and r.interval_boxes==0 and r.patch_count==0 and Bomb.calls==0,status=r.status.name)
for label,obj in [('CircleSubclass',CS(F(0),F(0),F(3))),('CircleLike',CircleLike(F(0),F(0),F(3))),('tuple',(F(0),F(0),F(3)) )]:
    r=ReachEngine().certify([obj],F(1)); accounting(r)
    rec('record_'+label,r.status is Status.INPUT_INVALID and r.interval_boxes==0,status=r.status.name)
for label,v in [('int',1),('Fraction',F(1))]:
    r=ReachEngine(max_depth=30).certify([base],v); accounting(r)
    rec('supported_'+label,r.status is Status.VALID and type(r.r0) is F,status=r.status.name,r0=str(r.r0))
for label,v in [('bool',True),('IntSubclass',IS(4))]+(([('np.int64',np.int64(4))] if np is not None else [])):
    for arg in ('pieces_per_quarter','max_depth','max_boxes'):
        kw={'pieces_per_quarter':4,'max_depth':18,'max_boxes':300000};kw[arg]=v
        try: ReachEngine(**kw)
        except TypeError: ok=True
        else: ok=False
        rec(f'ctor_{arg}_{label}',ok)
invalid=[('external_tangent',[Circle(0,0,2),Circle(4,0,2)]),('internal_tangent',[Circle(0,0,5),Circle(3,0,2)]),('intersection',[Circle(0,0,3),Circle(4,0,3)]),('duplicate',[Circle(0,0,3),Circle(0,0,3)]),('zero_radius',[Circle(0,0,0)]),('negative_radius',[Circle(0,0,-1)]),('empty',[])]
for label,c in invalid:
    r=ReachEngine().certify(c,F(1,10));accounting(r)
    rec('invalid_link_'+label,r.status is Status.INPUT_INVALID and r.interval_boxes==0 and r.patch_count==0,status=r.status.name,reason=r.reason)
# Validator acceptance, tested without an expensive near-equality global proof.
valid_links=[('nested',[Circle(0,0,2),Circle(0,0,5)]),('multi_nested',[Circle(0,0,2),Circle(0,0,5),Circle(0,0,9),Circle(0,0,14)]),('near_external',[Circle(0,0,2),Circle(F(4000001,1000000),0,2)]),('near_internal',[Circle(0,0,5),Circle(F(2999999,1000000),0,2)])]
for label,c in valid_links:
    try:
        atlas=ReachEngine().build_atlas(c)
        ok=len(atlas)==len(c)*16
    except Exception as exc:
        ok=False; atlas=[]; err=repr(exc)
    else:
        err=''
    rec('valid_link_validator_'+label,ok,patches=len(atlas),error=err)

out={'total':len(rows),'numpy':np is not None,'failures':[x for x in rows if not x['passed']]}
Path('/mnt/data/phase_c1_independent_audit_20260823/contract_stress_v2_results.json').write_text(json.dumps({'summary':out,'rows':rows},indent=2,default=str))
print('SUMMARY',json.dumps(out),flush=True)
