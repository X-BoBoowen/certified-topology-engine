from __future__ import annotations
import contextlib, importlib.util, io, json, runpy, sys
from fractions import Fraction
from pathlib import Path

root = Path(__file__).resolve().parent
base = root / "frozen_baseline" / "c1_files"
engine_path = base / "reach_engine.py"
suite_path = base / "run_suite.py"
if not engine_path.exists() or not suite_path.exists():
    raise SystemExit("baseline source files not located")

spec = importlib.util.spec_from_file_location("reach_engine", engine_path)
mod = importlib.util.module_from_spec(spec)
sys.modules["reach_engine"] = mod
assert spec.loader is not None
spec.loader.exec_module(mod)

records = []
original = mod.ReachEngine.certify

def qstr(value):
    if type(value) is Fraction:
        return f"{value.numerator}/{value.denominator}"
    if type(value) is int:
        return f"{value}/1"
    return {"unsupported_type": type(value).__name__, "repr": repr(value)}

def wrapped(self, circles, r0):
    circle_list = list(circles)
    result = original(self, circle_list, r0)
    records.append({
        "call_index": len(records),
        "circles": [
            {"cx": qstr(c.cx), "cy": qstr(c.cy), "radius": qstr(c.radius)}
            for c in circle_list
        ],
        "r0": qstr(r0),
        "status": result.status.value if hasattr(result.status, "value") else str(result.status),
        "reason": getattr(result, "reason", ""),
    })
    return result

mod.ReachEngine.certify = wrapped
old_cwd = Path.cwd()
try:
    import os
    os.chdir(base)
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        try:
            runpy.run_path(str(suite_path), run_name="__main__")
        except SystemExit as exc:
            if exc.code not in (0, None):
                raise
finally:
    os.chdir(old_cwd)

(root / "results" / "c1_captured_calls.json").write_text(json.dumps(records, indent=2, sort_keys=True), encoding="utf-8")
print(len(records))
