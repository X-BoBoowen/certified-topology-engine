from __future__ import annotations
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
LOG = ROOT / "logs"
LOG.mkdir(exist_ok=True)

commands = [
    ("py_compile", [sys.executable, "-m", "compileall", "-q", "src", "tests", "run_general_suite.py", "run_property_suite.py", "run_invalid_suite.py", "run_proof_replay.py", "run_float_path_audit.py"]),
    ("pytest", [sys.executable, "-m", "pytest", "-q"]),
    ("property_suite", [sys.executable, "run_property_suite.py"]),
    ("general_suite", [sys.executable, "run_general_suite.py"]),
    ("invalid_suite", [sys.executable, "run_invalid_suite.py"]),
    ("proof_replay", [sys.executable, "run_proof_replay.py"]),
    ("float_path_audit", [sys.executable, "run_float_path_audit.py"]),
]
rows = []
for name, command in commands:
    completed = subprocess.run(command, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (LOG / f"VERIFY_{name.upper()}.txt").write_text(completed.stdout, encoding="utf-8")
    rows.append({"name": name, "command": command, "returncode": completed.returncode, "output_file": f"logs/VERIFY_{name.upper()}.txt"})

expected_outer = "0edae927f9cd75b5140ced9e925b70da0cbaa785f6cfe077789e046b0e368ee0"
expected_inner = "94903d2a45f08e14cd153782e949c1301dbc8e67c863c25cce958ee1581aa6fe"
outer = ROOT / "frozen_baseline" / "Phase_C1_Exact_Input_Soundness_Repair_Bundle_20260823.zip"
inner_candidates = list((ROOT / "frozen_baseline" / "extracted").rglob("phase_c_reach_engine_prototype.zip"))

def digest(path):
    h=hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1<<20), b""):
            h.update(chunk)
    return h.hexdigest()

baseline = {
    "outer_path": str(outer.relative_to(ROOT)) if outer.exists() else None,
    "outer_sha256": digest(outer) if outer.exists() else None,
    "outer_expected": expected_outer,
    "outer_unchanged": outer.exists() and digest(outer) == expected_outer,
    "inner_path": str(inner_candidates[0].relative_to(ROOT)) if inner_candidates else None,
    "inner_sha256": digest(inner_candidates[0]) if inner_candidates else None,
    "inner_expected": expected_inner,
    "inner_unchanged": bool(inner_candidates) and digest(inner_candidates[0]) == expected_inner,
}
(ROOT / "results" / "baseline_hash_verification.json").write_text(json.dumps(baseline, indent=2, sort_keys=True), encoding="utf-8")
all_passed = all(row["returncode"] == 0 for row in rows) and baseline["outer_unchanged"] and baseline["inner_unchanged"]
summary = {"all_commands_passed": all_passed, "commands": rows, "baseline": baseline}
# Pull concise suite facts when available.
for key, rel in [
    ("general_suite", "results/general_suite_results.json"),
    ("property_suite", "results/property_results.json"),
    ("invalid_suite", "results/invalid_suite_results.json"),
    ("proof_replay", "results/proof_replay_results.json"),
    ("float_path_audit", "results/float_path_audit.json"),
]:
    path = ROOT / rel
    if path.exists():
        summary[key] = json.loads(path.read_text(encoding="utf-8"))
(ROOT / "results" / "verification_summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
print(json.dumps({"all_commands_passed": all_passed, "returncodes": {r['name']: r['returncode'] for r in rows}, "baseline": baseline}, indent=2))
raise SystemExit(0 if all_passed else 1)
