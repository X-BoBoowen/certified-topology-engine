from __future__ import annotations
import json, re
from pathlib import Path

ROOT=Path(__file__).resolve().parent
summary=json.loads((ROOT/'results/verification_summary.json').read_text()) if (ROOT/'results/verification_summary.json').exists() else {}
general=summary.get('general_suite',{})
diff=general.get('circle_differential',{})
knot=general.get('knot_suite',{})
prop=summary.get('property_suite',{})
invalid=summary.get('invalid_suite',{})
replay=summary.get('proof_replay',{})
float_audit=summary.get('float_path_audit',{})

# Recover baseline names when available.
baseline_json=ROOT/'frozen_baseline/c1_files/synthetic_results.json'
names=[]
if baseline_json.exists():
    obj=json.loads(baseline_json.read_text())
    candidates=obj if isinstance(obj,list) else obj.get('scenarios',obj.get('results',[])) if isinstance(obj,dict) else []
    if isinstance(candidates,list):
        for row in candidates:
            if isinstance(row,dict): names.append(row.get('name',row.get('scenario','')))
rows=diff.get('rows',[])
lines=['# Scenario–Test Mapping','','## Phase C.1 differential scenarios','','| Index | Frozen scenario | C.1 status | General status | Analytic-safe at r0 | False VALID |','|---:|---|---|---|---:|---:|']
for i,row in enumerate(rows):
    name=names[i] if i<len(names) and names[i] else f'captured_call_{i:02d}'
    lines.append(f"| {i} | `{name}` | `{row.get('status','')}` | `{row.get('general_status','')}` | {row.get('analytic_safe',False)} | {row.get('false_valid',False)} |")
lines += ['','## Piecewise-C² knot/cell suite','','| Scenario | Expected semantics | Actual | Passed |','|---|---|---|---:|']
for row in knot.get('rows',[]):
    lines.append(f"| `{row.get('name')}` | `{row.get('expected')}` | `{row.get('status')}` | {row.get('passed')} |")
lines += ['','## Pytest mapping','',
'- `test_exact_input*.py`: exact numeric boundary for field, coefficients, rectangles, frames, intervals, and `r0`.',
'- `test_cell_complex.py`, `test_c2_interfaces.py`: no gaps/overlaps and exact C² interface identities.',
'- `test_guard_certificate.py`, `test_implicit_patch.py`: unique graph guards and certified implicit position/derivatives.',
'- `test_atlas_coverage.py`, `test_knot_and_corner.py`, `test_loop_ownership.py`: field-level coverage and proposal-assisted loop certificates.',
'- `test_delta_loc.py`: positive nonlocal separation and failure-to-UNKNOWN.',
'- `test_pair_cover.py`: exhaustive DCSD strict/equality/above-reach behavior.',
'- `test_curvature.py`: exact curvature inequality closure.',
'- `test_general_reach_engine.py`: sole final VALID gate and exact `r0` boundary.',
'- `test_circle_differential.py`: all 22 frozen circle calls.',
'- `test_piecewise_spline_suite.py`: genuine C² knot/corner fields.',
'- `test_adversarial_fields.py`: singular, crossing, and boundary-contact fields.',
'- `test_property_suite.py`: exact interval inclusion regression.',
'- `test_proof_log_replay.py`: proof-log integrity and tamper detection.',
]
(ROOT/'docs/SCENARIO_TEST_MAPPING.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')

commands=summary.get('commands',[])
command_table='\n'.join(f"| `{r['name']}` | {r['returncode']} | `{r['output_file']}` |" for r in commands)
all_pass=summary.get('all_commands_passed',False)
outer=summary.get('baseline',{}).get('outer_sha256','missing')
inner=summary.get('baseline',{}).get('inner_sha256','missing')
report=f'''# Phase C.2 Research Status

## 1. Frozen Baseline

Phase C.1 was copied into `frozen_baseline/` and never imported into the new certificate path. Fresh hash verification recorded:

```text
outer: {outer}
inner: {inner}
```

Expected values are the frozen Phase C.1 hashes. The verification summary reports `outer_unchanged={summary.get('baseline',{}).get('outer_unchanged')}` and `inner_unchanged={summary.get('baseline',{}).get('inner_unchanged')}`.

## 2. Exact General-Field Input Contract

Implemented:

- exact rational rectangular structured cell complex;
- exact sparse polynomials in `Fraction` coefficients;
- exact first and second derivatives;
- exact C² identities on complete shared edges;
- interval-certified zero-free domain boundary;
- rejection of floats, decimals, booleans, strings, NumPy/custom numeric objects, and implicit coercion.

The detailed contract is in `docs/GENERAL_SPLINE_INPUT_CONTRACT.md`.

## 3. Rational Frame Dictionary

The four exact undirected normals `(1,0)`, `(0,1)`, `(1,1)`, `(1,-1)` are implemented. Exact enumeration verifies the selected frame satisfies

\[
2|g\cdot e|\le |g\cdot n|.
\]

No square root or floating direction is used by the certificate path.

## 4. Guard and Implicit-Patch Certificates

Implemented runtime predicates:

- strict normal monotonicity;
- slope ratio at most one half;
- opposite normal-face signs;
- multi-cell derivative/evaluation hulls;
- uniform implicit root brackets;
- interval enclosures for `gamma`, `gamma_prime`, and `gamma_second`.

Every accepted guard is checked directly against every incident polynomial piece.

## 5. Atlas Coverage and Loop Ownership

The zero-box coverage verifier is exact and exhaustive: every field cell is recursively covered by zero-free boxes or by an accepted unique-branch owner slab; budget exhaustion returns `UNKNOWN`.

The current loop-order constructor is **proposal-assisted**. Exact circle candidates supply only a proposed cyclic order; the implementation independently checks every guard and common-guard adjacency and separately proves field-level zero-set coverage. However, it does not yet discover a cyclic owner order from an arbitrary field with no candidates.

This remaining field-only atlas-construction gap prevents `READY FOR INDEPENDENT GENERAL-SPLINE AUDIT`.

## 6. Knot / Cell-Edge / Corner Handling

The knot suite uses positive C² piecewise cubic factors multiplying known circle products. The zero set is unchanged, while polynomial pieces and derivative hulls genuinely cross vertical knots, horizontal knots, multiple knots, and an exact cell corner. Incident pieces are all evaluated; no epsilon perturbation is used.

Knot suite: {knot.get('scenario_count','unknown')} scenarios, {knot.get('failure_count','unknown')} semantic failures.

## 7. General delta_loc

For a completed certified atlas, every unordered nonlocal patch pair is exhaustively subdivided until a strictly positive exact squared-distance lower bound is obtained. A dyadic rational square-root lower bound yields a positive `delta_loc`. Any unresolved pair makes the entire stage `UNKNOWN`.

This module is implemented and used by every successful synthetic certificate.

## 8. Exhaustive Pair Cover

No BVH or heuristic filtering is present. All unordered patch pairs are generated. Only four sound exclusions are used:

1. certified common-guard locality;
2. exact distance lower bound at least `(2*r0)^2`;
3. zero excluded from `G1`;
4. zero excluded from `G2`.

Subdivision is cover-preserving and unresolved leaves force `UNKNOWN`.

## 9. Curvature and Reach Soundness

Curvature is certified without square roots by comparing

\[
\det(\gamma',\gamma'')^2 r_0^2
\le \|\gamma'\|^6.
\]

`GeneralReachEngine.certify` is the only construction point for `VALID`; it requires valid field, atlas, `delta_loc`, curvature, and DCSD stages. `docs/GENERAL_REACH_SOUNDNESS.md` records the formal dependency.

## 10. Differential Circle Results

Frozen calls replayed: {diff.get('scenario_count','unknown')}.

General-engine `VALID` results: {diff.get('general_valid_count','unknown')}.

False-valid count against the exact analytic circle-link condition: {diff.get('false_valid_count','unknown')}.

The Phase C.1 implementation remains a read-only differential oracle.

## 11. Piecewise-Spline Synthetic Results

The knot/cell suite contains true piecewise-polynomial fields rather than copied identical pieces. Result JSON and individual proof logs are included in `results/` and `proof_logs/`.

## 12. Invalid and Adversarial Results

Invalid/singular scenarios: {invalid.get('scenario_count','unknown')}; semantic failures: {invalid.get('failure_count','unknown')}.

The suite includes squared singular circles, crossings, boundary zeros, C² mismatch, and exact-input violations. None is permitted to produce `VALID`.

Exact-reference inclusion checks: {prop.get('checks','unknown')}.

Float-path AST violations: {len(float_audit.get('violations',[])) if isinstance(float_audit,dict) else 'unknown'}.

## 13. Proof-Log Replay

Replay logs checked: {replay.get('count','unknown')}; replay failures: {replay.get('failures','unknown')}.

The replay tool verifies log hashes and that a final `VALID` log contains all mandatory `VALID` stages. It is a structural replay, not yet an independent arithmetic recomputation of every leaf interval.

## 14. Remaining Gaps

1. No automatic field-only loop discovery and half-open owner-order constructor.
2. Successful atlases currently use verified circle-derived guard proposals.
3. No BVH by design; scaling remains quadratic.
4. No real-image pilot, mask compiler, XOR area, or conformal code.
5. Equality may remain `UNKNOWN`.
6. Proof replay is structural rather than a second arithmetic kernel.

## 15. Final Verdict

# PIVOT

The exact field adapter, guard verifier, implicit evaluator, coverage proof, `delta_loc`, exhaustive pair solver, curvature certificate, and final sound gate are implemented and pass the included synthetic verification when proposal candidates are available. There is no evidence of a false `VALID` in the frozen-circle differential or knot-transformed suites.

Nevertheless, the phase requested a general field-only spline atlas. The current candidate-free call returns `UNKNOWN`; automatic cycle discovery and unique owner construction remain absent. Calling this `READY FOR INDEPENDENT GENERAL-SPLINE AUDIT` would overstate what was built.

The next permissible work is narrowly defined: replace circle-derived proposal ordering with an exact field-only atlas traversal while preserving the existing coverage and pair-solver certificates. BVH, real data, XOR area, and conformal remain prohibited.

## Fresh verification table

| Command | Exit code | Full output |
|---|---:|---|
{command_table}

Overall automated gate: `{all_pass}`.
'''
(ROOT/'PHASE_C2_RESEARCH_STATUS.md').write_text(report,encoding='utf-8')
