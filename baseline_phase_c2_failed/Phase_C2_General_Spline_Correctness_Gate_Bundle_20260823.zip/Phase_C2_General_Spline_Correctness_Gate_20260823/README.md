# Phase C.2 General Piecewise-Polynomial Reach Correctness Gate

This is a correctness-first general piecewise-polynomial
implicit-curve reference engine.

It does not include a certified BVH.
It has not been evaluated on real images.
It does not implement conformal certification.

## Frozen Phase C.1 baseline

The attached Phase C.1 ZIP is copied byte-for-byte and checked against:

```text
outer: 0edae927f9cd75b5140ced9e925b70da0cbaa785f6cfe077789e046b0e368ee0
inner: 94903d2a45f08e14cd153782e949c1301dbc8e67c863c25cce958ee1581aa6fe
```

The Phase C.2 code lives in a separate package and does not import or modify the Phase C.1 implementation except in differential test tooling.

## What is implemented

- strict exact-rational input contract;
- finite rational rectangular cell complexes;
- exact sparse rational bivariate polynomials;
- exact first/second derivatives and C² edge identities;
- multi-cell guard certification;
- interval implicit graph evaluator for position, first derivative, and second derivative;
- exact field-level zero-box coverage;
- proposal-assisted loop/guard atlas verification;
- certified positive local-diagonal radius;
- exhaustive unordered patch-pair DCSD solver;
- certified curvature comparison;
- one final `VALID` gate;
- replayable JSON proof logs;
- Phase C.1 differential circle suite;
- genuine piecewise-C² knot/corner suite;
- invalid/singular suite;
- more than 100,000 exact-reference inclusion checks.

## Important verdict boundary

The package verdict is **PIVOT**. Although all certificate predicates are exact and the proposal-assisted synthetic engine is sound under its runtime proof obligations, the atlas candidate order is not yet discovered automatically from an arbitrary field. The implementation therefore does not claim to be a complete general spline reach engine.

## Environment and installation

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
python -m pip install -r requirements.txt
python -m pip install -e .
```

## Complete verification commands

```bash
python -m compileall -q src tests \
  run_general_suite.py run_property_suite.py run_invalid_suite.py \
  run_proof_replay.py run_float_path_audit.py

python -m pytest -q
python run_property_suite.py
python run_general_suite.py
python run_invalid_suite.py
python run_proof_replay.py
python run_float_path_audit.py
python verify_all.py
```

## Status semantics

- `VALID`: all recorded proof obligations closed; under the documented hypotheses, `reach(F^{-1}(0)) >= r0`.
- `UNKNOWN`: the input may be valid, but at least one coverage, interval, curvature, distance, or budget obligation did not close.
- `INPUT_INVALID`: the exact field contract failed.

No ordinary float is accepted in a certificate predicate.
