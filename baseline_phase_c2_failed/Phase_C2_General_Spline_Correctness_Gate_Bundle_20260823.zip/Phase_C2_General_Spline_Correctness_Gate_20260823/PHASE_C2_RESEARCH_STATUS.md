# Phase C.2 Research Status

## 1. Frozen Baseline

Phase C.1 was copied into `frozen_baseline/` and never imported into the new certificate path. Fresh hash verification recorded:

```text
outer: 0edae927f9cd75b5140ced9e925b70da0cbaa785f6cfe077789e046b0e368ee0
inner: 94903d2a45f08e14cd153782e949c1301dbc8e67c863c25cce958ee1581aa6fe
```

Expected values are the frozen Phase C.1 hashes. The verification summary reports `outer_unchanged=True` and `inner_unchanged=True`.

## 2. Exact General-Field Input Contract

Implemented:

- exact rational rectangular structured cell complex;
- exact sparse polynomials in `Fraction` coefficients;
- exact first and second derivatives;
- exact C² identities on complete shared edges;
- interval-certified zero-free domain boundary;
- rejection of floats, decimals, booleans, strings, NumPy/custom numeric objects, and implicit coercion.

The detailed contract is in `docs/GENERAL_SPLINE_INPUT_CONTRACT.md`.

## 3. Rational Frame Dictionary

The four exact undirected normals `(1,0)`, `(0,1)`, `(1,1)`, `(1,-1)` are implemented. Exact enumeration verifies the selected frame satisfies

\[
2|g\cdot e|\le |g\cdot n|.
\]

No square root or floating direction is used by the certificate path.

## 4. Guard and Implicit-Patch Certificates

Implemented runtime predicates:

- strict normal monotonicity;
- slope ratio at most one half;
- opposite normal-face signs;
- multi-cell derivative/evaluation hulls;
- uniform implicit root brackets;
- interval enclosures for `gamma`, `gamma_prime`, and `gamma_second`.

Every accepted guard is checked directly against every incident polynomial piece.

## 5. Atlas Coverage and Loop Ownership

The zero-box coverage verifier is exact and exhaustive: every field cell is recursively covered by zero-free boxes or by an accepted unique-branch owner slab; budget exhaustion returns `UNKNOWN`.

The current loop-order constructor is **proposal-assisted**. Exact circle candidates supply only a proposed cyclic order; the implementation independently checks every guard and common-guard adjacency and separately proves field-level zero-set coverage. However, it does not yet discover a cyclic owner order from an arbitrary field with no candidates.

This remaining field-only atlas-construction gap prevents `READY FOR INDEPENDENT GENERAL-SPLINE AUDIT`.

## 6. Knot / Cell-Edge / Corner Handling

The knot suite uses positive C² piecewise cubic factors multiplying known circle products. The zero set is unchanged, while polynomial pieces and derivative hulls genuinely cross vertical knots, horizontal knots, multiple knots, and an exact cell corner. Incident pieces are all evaluated; no epsilon perturbation is used.

Knot suite: unknown scenarios, unknown semantic failures.

## 7. General delta_loc

For a completed certified atlas, every unordered nonlocal patch pair is exhaustively subdivided until a strictly positive exact squared-distance lower bound is obtained. A dyadic rational square-root lower bound yields a positive `delta_loc`. Any unresolved pair makes the entire stage `UNKNOWN`.

This module is implemented and used by every successful synthetic certificate.

## 8. Exhaustive Pair Cover

No BVH or heuristic filtering is present. All unordered patch pairs are generated. Only four sound exclusions are used:

1. certified common-guard locality;
2. exact distance lower bound at least `(2*r0)^2`;
3. zero excluded from `G1`;
4. zero excluded from `G2`.

Subdivision is cover-preserving and unresolved leaves force `UNKNOWN`.

## 9. Curvature and Reach Soundness

Curvature is certified without square roots by comparing

\[
\det(\gamma',\gamma'')^2 r_0^2
\le \|\gamma'\|^6.
\]

`GeneralReachEngine.certify` is the only construction point for `VALID`; it requires valid field, atlas, `delta_loc`, curvature, and DCSD stages. `docs/GENERAL_REACH_SOUNDNESS.md` records the formal dependency.

## 10. Differential Circle Results

Frozen calls replayed: unknown.

General-engine `VALID` results: unknown.

False-valid count against the exact analytic circle-link condition: unknown.

The Phase C.1 implementation remains a read-only differential oracle.

## 11. Piecewise-Spline Synthetic Results

The knot/cell suite contains true piecewise-polynomial fields rather than copied identical pieces. Result JSON and individual proof logs are included in `results/` and `proof_logs/`.

## 12. Invalid and Adversarial Results

Invalid/singular scenarios: unknown; semantic failures: unknown.

The suite includes squared singular circles, crossings, boundary zeros, C² mismatch, and exact-input violations. None is permitted to produce `VALID`.

Exact-reference inclusion checks: unknown.

Float-path AST violations: 0.

## 13. Proof-Log Replay

Replay logs checked: unknown; replay failures: unknown.

The replay tool verifies log hashes and that a final `VALID` log contains all mandatory `VALID` stages. It is a structural replay, not yet an independent arithmetic recomputation of every leaf interval.

## 14. Remaining Gaps

1. No automatic field-only loop discovery and half-open owner-order constructor.
2. Successful atlases currently use verified circle-derived guard proposals.
3. No BVH by design; scaling remains quadratic.
4. No real-image pilot, mask compiler, XOR area, or conformal code.
5. Equality may remain `UNKNOWN`.
6. Proof replay is structural rather than a second arithmetic kernel.

## 15. Final Verdict

# PIVOT

The exact field adapter, guard verifier, implicit evaluator, coverage proof, `delta_loc`, exhaustive pair solver, curvature certificate, and final sound gate are implemented and pass the included synthetic verification when proposal candidates are available. There is no evidence of a false `VALID` in the frozen-circle differential or knot-transformed suites.

Nevertheless, the phase requested a general field-only spline atlas. The current candidate-free call returns `UNKNOWN`; automatic cycle discovery and unique owner construction remain absent. Calling this `READY FOR INDEPENDENT GENERAL-SPLINE AUDIT` would overstate what was built.

The next permissible work is narrowly defined: replace circle-derived proposal ordering with an exact field-only atlas traversal while preserving the existing coverage and pair-solver certificates. BVH, real data, XOR area, and conformal remain prohibited.

## Fresh verification table

| Command | Exit code | Full output |
|---|---:|---|
| `py_compile` | 0 | `logs/VERIFY_PY_COMPILE.txt` |
| `pytest` | 1 | `logs/VERIFY_PYTEST.txt` |
| `property_suite` | 1 | `logs/VERIFY_PROPERTY_SUITE.txt` |
| `general_suite` | 1 | `logs/VERIFY_GENERAL_SUITE.txt` |
| `invalid_suite` | 1 | `logs/VERIFY_INVALID_SUITE.txt` |
| `proof_replay` | 1 | `logs/VERIFY_PROOF_REPLAY.txt` |
| `float_path_audit` | 0 | `logs/VERIFY_FLOAT_PATH_AUDIT.txt` |

Overall automated gate: `False`.
