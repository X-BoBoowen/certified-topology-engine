from __future__ import annotations
import ast
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
violations = []
for path in sorted((ROOT / "src" / "phase_c2_general_spline").glob("*.py")):
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, float):
            violations.append({"file": str(path.relative_to(ROOT)), "line": node.lineno, "kind": "float_literal", "value": repr(node.value)})
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in {"float", "Decimal"}:
            violations.append({"file": str(path.relative_to(ROOT)), "line": node.lineno, "kind": "forbidden_constructor", "value": node.func.id})
result = {"files_scanned": len(list((ROOT / "src" / "phase_c2_general_spline").glob("*.py"))), "violations": violations}
(ROOT / "results" / "float_path_audit.json").write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
print(json.dumps(result, indent=2))
if violations:
    raise SystemExit(1)
