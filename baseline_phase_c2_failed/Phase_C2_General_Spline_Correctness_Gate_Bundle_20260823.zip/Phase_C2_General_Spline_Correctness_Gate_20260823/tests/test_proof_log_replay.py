from fractions import Fraction as F
import json

from phase_c2_general_spline.general_reach_engine import GeneralReachEngine
from phase_c2_general_spline.proof_log import replay_structural_check
from phase_c2_general_spline.scenarios import CircleSpec, circle_product_field, circle_proposals
from phase_c2_general_spline.status import Status


def test_valid_proof_log_replays_and_tamper_is_detected(tmp_path):
    circles = [CircleSpec(F(0), F(0), F(2))]
    field = circle_product_field(circles, F(4))
    result = GeneralReachEngine(pair_depth=18, pair_boxes=1200000).certify(
        field, F(3, 2), proposals=circle_proposals(circles, pieces_per_quarter=8)
    )
    assert result.status is Status.VALID
    path = tmp_path / "proof.json"
    result.data["proof_log"].write(path)
    assert replay_structural_check(path) == (True, "OK")
    payload = json.loads(path.read_text())
    payload["final_reason"] = "tampered"
    path.write_text(json.dumps(payload))
    assert replay_structural_check(path)[0] is False
