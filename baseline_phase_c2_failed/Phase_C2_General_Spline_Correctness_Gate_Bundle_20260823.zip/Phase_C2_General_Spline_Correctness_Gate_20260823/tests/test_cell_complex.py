from fractions import Fraction as F

from phase_c2_general_spline.cell_complex import Cell, ExactRectangle, PiecewisePolynomialField2D
from phase_c2_general_spline.rational_polynomial import RationalPolynomial2D as P
from phase_c2_general_spline.status import Status


def constant(v):
    return P({(0, 0): F(v)})


def test_structured_complex_rejects_gap_and_overlap():
    domain = ExactRectangle(F(0), F(2), F(0), F(1))
    gap = PiecewisePolynomialField2D(domain, [Cell("a", ExactRectangle(F(0), F(1), F(0), F(1)), constant(1))])
    assert gap.validate().status is Status.INPUT_INVALID

    overlap = PiecewisePolynomialField2D(domain, [
        Cell("a", ExactRectangle(F(0), F(3, 2), F(0), F(1)), constant(1)),
        Cell("b", ExactRectangle(F(1), F(2), F(0), F(1)), constant(1)),
    ])
    assert overlap.validate().status is Status.INPUT_INVALID


def test_valid_two_cell_complex_builds_incidence():
    domain = ExactRectangle(F(-2), F(2), F(-2), F(2))
    p = P({(2, 0): F(1), (0, 2): F(1), (0, 0): F(-1)})
    field = PiecewisePolynomialField2D(domain, [
        Cell("left", ExactRectangle(F(-2), F(0), F(-2), F(2)), p),
        Cell("right", ExactRectangle(F(0), F(2), F(-2), F(2)), p),
    ])
    result = field.validate()
    assert result.status is Status.VALID
    assert field.adjacency["left"] == {"right"}
