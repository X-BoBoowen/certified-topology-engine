from fractions import Fraction as F

from phase_c2_general_spline.general_reach_engine import GeneralReachEngine
from phase_c2_general_spline.scenarios import CircleSpec, circle_product_field, circle_proposals
from phase_c2_general_spline.status import Status


def test_final_valid_path_for_strict_circle():
    circles = [CircleSpec(F(0), F(0), F(2))]
    field = circle_product_field(circles, F(4), grid_x=(F(0),), grid_y=(F(0),), knot_strength=F(1, 100))
    result = GeneralReachEngine(
        atlas_depth=10,
        atlas_boxes=50000,
        delta_depth=14,
        delta_boxes=800000,
        pair_depth=18,
        pair_boxes=1200000,
    ).certify(field, F(3, 2), proposals=circle_proposals(circles))
    assert result.status is Status.VALID
    assert result.data["proof_log"].final_status == "VALID"


def test_float_r0_is_input_invalid_before_certificate_work():
    circles = [CircleSpec(F(0), F(0), F(2))]
    field = circle_product_field(circles, F(4))
    result = GeneralReachEngine().certify(field, 1.5, proposals=circle_proposals(circles))
    assert result.status is Status.INPUT_INVALID


def test_above_reach_never_valid():
    circles = [CircleSpec(F(0), F(0), F(2)), CircleSpec(F(21, 5), F(0), F(2))]
    field = circle_product_field(circles, F(7))
    result = GeneralReachEngine(pair_depth=20, pair_boxes=1500000).certify(
        field, F(1, 5), proposals=circle_proposals(circles)
    )
    assert result.status is not Status.VALID


def test_missing_atlas_proposals_is_unknown_not_valid():
    circles = [CircleSpec(F(0), F(0), F(2))]
    field = circle_product_field(circles, F(4))
    assert GeneralReachEngine().certify(field, F(1), proposals=()).status is Status.UNKNOWN
