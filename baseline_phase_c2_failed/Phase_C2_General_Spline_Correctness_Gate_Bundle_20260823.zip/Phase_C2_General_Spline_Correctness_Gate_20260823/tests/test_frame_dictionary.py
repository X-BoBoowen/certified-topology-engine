from fractions import Fraction as F

from phase_c2_general_spline.frame_dictionary import FRAME_DICTIONARY, select_frame_for_vector


def test_dictionary_has_four_undirected_exact_rational_frames():
    assert {(f.nx, f.ny) for f in FRAME_DICTIONARY} == {(1, 0), (0, 1), (1, 1), (1, -1)}
    for frame in FRAME_DICTIONARY:
        assert frame.ex * frame.nx + frame.ey * frame.ny == 0
        assert frame.ex**2 + frame.ey**2 == frame.nx**2 + frame.ny**2


def test_dictionary_half_slope_coverage_for_integer_vectors():
    for gx in range(-20, 21):
        for gy in range(-20, 21):
            if gx == gy == 0:
                continue
            frame = select_frame_for_vector(F(gx), F(gy))
            de = gx * frame.ex + gy * frame.ey
            dn = gx * frame.nx + gy * frame.ny
            assert 2 * abs(de) <= abs(dn)
