from fractions import Fraction as F
import random

from phase_c2_general_spline.interval import RationalInterval as I
from phase_c2_general_spline.rational_polynomial import RationalPolynomial2D as P


def test_1000_exact_polynomial_interval_inclusions():
    rng = random.Random(712367)
    for _ in range(1000):
        p = P({(2, 0): F(rng.randint(-5, 5)), (1, 1): F(rng.randint(-5, 5)), (0, 2): F(rng.randint(-5, 5)), (0, 0): F(rng.randint(-5, 5))})
        x0 = F(rng.randint(-10, 0), 5)
        x1 = F(rng.randint(1, 10), 5)
        y0 = F(rng.randint(-10, 0), 5)
        y1 = F(rng.randint(1, 10), 5)
        x = (x0 + x1) / 2
        y = (y0 + y1) / 2
        assert p.evaluate_interval(I(x0, x1), I(y0, y1)).contains(p.evaluate(x, y))
