from fractions import Fraction as F

from phase_c2_general_spline.interval import RationalInterval as I
from phase_c2_general_spline.rational_polynomial import RationalPolynomial2D


def test_exact_differentiation_and_point_evaluation():
    p = RationalPolynomial2D({(2, 0): F(1), (1, 1): F(3), (0, 0): F(-4)})
    assert p.dx().coefficients == {(1, 0): F(2), (0, 1): F(3)}
    assert p.dy().coefficients == {(1, 0): F(3)}
    assert p.evaluate(F(2), F(5)) == F(30)


def test_interval_evaluation_contains_corner_and_interior_values():
    p = RationalPolynomial2D({(2, 0): F(1), (0, 2): F(1), (0, 0): F(-1)})
    enclosure = p.evaluate_interval(I(F(-1), F(1)), I(F(-1), F(1)))
    for x, y in [(F(-1), F(0)), (F(0), F(0)), (F(1, 2), F(1, 3))]:
        assert enclosure.contains(p.evaluate(x, y))


def test_edge_restriction_is_exact_univariate_polynomial():
    p = RationalPolynomial2D({(2, 0): F(1), (1, 1): F(2), (0, 2): F(3)})
    assert p.restrict_x(F(2)) == {0: F(4), 1: F(4), 2: F(3)}
    assert p.restrict_y(F(-1)) == {0: F(3), 1: F(-2), 2: F(1)}
