from fractions import Fraction as F

from phase_c2_general_spline.scenarios import CircleSpec, circle_product_field, circle_proposals
from phase_c2_general_spline.spline_atlas import AtlasBuilder
from phase_c2_general_spline.status import Status


def test_multiple_nested_loops_are_recorded_as_disjoint_cycles():
    circles = [CircleSpec(F(0), F(0), F(3)), CircleSpec(F(0), F(0), F(1))]
    field = circle_product_field(circles, F(5))
    result = AtlasBuilder(max_cover_depth=10, max_cover_boxes=30000).build(field, proposals=circle_proposals(circles))
    assert result.status is Status.VALID
    atlas = result.data["atlas"]
    assert len(atlas.loop_cycles) == 2
    assert {p.loop_id for p in atlas.patches} == {0, 1}
