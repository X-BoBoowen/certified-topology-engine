from fractions import Fraction as F

import pytest

from phase_c2_general_spline.interval import RationalInterval as I


def test_interval_arithmetic_contains_exact_results():
    x = I(F(-2), F(3))
    y = I(F(4), F(5))
    assert x + y == I(F(2), F(8))
    assert x * y == I(F(-10), F(15))
    assert x.square() == I(F(0), F(9))


def test_interval_division_rejects_zero_denominator_interval():
    with pytest.raises(ZeroDivisionError):
        I(F(1), F(2)) / I(F(-1), F(1))


def test_interval_intersection_and_hull():
    assert I(F(0), F(3)).intersection(I(F(2), F(4))) == I(F(2), F(3))
    assert I.hull_many([I(F(0), F(1)), I(F(-2), F(3))]) == I(F(-2), F(3))
