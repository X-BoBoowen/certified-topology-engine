from decimal import Decimal
from fractions import Fraction

import pytest

from phase_c2_general_spline.exact_types import ExactInputError, parse_rational, require_fraction


@pytest.mark.parametrize("value", [0.1, Decimal("0.1"), True, "1/10", object()])
def test_certificate_numeric_boundary_rejects_non_exact_types(value):
    with pytest.raises(ExactInputError):
        require_fraction(value, "value")


def test_builtin_int_is_converted_but_bool_is_not():
    assert require_fraction(3, "value") == Fraction(3, 1)
    with pytest.raises(ExactInputError):
        require_fraction(False, "value")


def test_parse_rational_is_explicit_and_exact():
    assert parse_rational("0.7") == Fraction(7, 10)
    assert parse_rational("-12/35") == Fraction(-12, 35)
    with pytest.raises(ValueError):
        parse_rational("nan")
