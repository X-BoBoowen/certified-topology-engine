from phase_c2_general_spline.reference_suites import run_knot_suite


def test_piecewise_c2_knot_suite_has_no_semantic_failure(tmp_path):
    result = run_knot_suite(tmp_path)
    assert result["scenario_count"] == 9
    assert result["failure_count"] == 0
