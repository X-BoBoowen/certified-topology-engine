from fractions import Fraction as F

from phase_c2_general_spline.curvature_certificate import certify_curvature
from phase_c2_general_spline.scenarios import CircleSpec, circle_product_field, circle_proposals
from phase_c2_general_spline.spline_atlas import AtlasBuilder
from phase_c2_general_spline.status import Status


def atlas_for(radius):
    circles = [CircleSpec(F(0), F(0), F(radius))]
    field = circle_product_field(circles, F(radius + 2))
    return AtlasBuilder(max_cover_depth=10, max_cover_boxes=30000).build(field, proposals=circle_proposals(circles)).data["atlas"]


def test_curvature_certificate_passes_strict_radius():
    assert certify_curvature(atlas_for(2), F(3, 2), max_depth=10).status is Status.VALID


def test_curvature_bound_not_closed_is_unknown_not_false_failure():
    assert certify_curvature(atlas_for(F(3, 4)), F(1), max_depth=10).status is Status.UNKNOWN
