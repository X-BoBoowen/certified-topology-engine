from fractions import Fraction as F

from phase_c2_general_spline.scenarios import CircleSpec, circle_product_field, circle_proposals
from phase_c2_general_spline.spline_atlas import AtlasBuilder
from phase_c2_general_spline.status import Status


def test_circle_crosses_vertical_and_horizontal_c2_knots():
    circles = [CircleSpec(F(0), F(0), F(2))]
    field = circle_product_field(circles, F(4), grid_x=(F(0),), grid_y=(F(0),), knot_strength=F(1, 100))
    assert field.validate().status is Status.VALID
    result = AtlasBuilder(max_cover_depth=9, max_cover_boxes=20000).build(field, proposals=circle_proposals(circles))
    assert result.status is Status.VALID
    atlas = result.data["atlas"]
    assert any(len(p.certificate.incident_cell_ids) > 1 for p in atlas.patches)


def test_zero_curve_through_exact_cell_corner_is_not_omitted():
    circles = [CircleSpec(F(0), F(0), F(2))]
    # (0,2) is a circle point and an exact cell-complex corner.
    field = circle_product_field(circles, F(4), grid_x=(F(0),), grid_y=(F(2),), knot_strength=F(1, 200))
    assert field.validate().status is Status.VALID
    result = AtlasBuilder(max_cover_depth=10, max_cover_boxes=30000).build(field, proposals=circle_proposals(circles))
    assert result.status is Status.VALID
    assert result.data["atlas"].coverage_unresolved == 0
