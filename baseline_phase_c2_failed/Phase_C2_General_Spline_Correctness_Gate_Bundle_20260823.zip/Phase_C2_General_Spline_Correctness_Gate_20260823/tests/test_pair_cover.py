from fractions import Fraction as F

from phase_c2_general_spline.delta_loc import certify_delta_loc
from phase_c2_general_spline.general_pair_solver import certify_dcsd
from phase_c2_general_spline.scenarios import CircleSpec, circle_product_field, circle_proposals
from phase_c2_general_spline.spline_atlas import AtlasBuilder
from phase_c2_general_spline.status import Status


def build(circles, domain=6):
    field = circle_product_field(circles, F(domain))
    atlas = AtlasBuilder(max_cover_depth=10, max_cover_boxes=50000).build(field, proposals=circle_proposals(circles)).data["atlas"]
    delta = certify_delta_loc(atlas, max_depth=14, max_boxes=500000)
    assert delta.status is Status.VALID
    return atlas, delta.data["delta_loc"]


def test_exhaustive_pair_solver_validates_strict_single_circle_margin():
    atlas, delta = build([CircleSpec(F(0), F(0), F(2))], 4)
    result = certify_dcsd(atlas, F(3, 2), delta_loc=delta, max_depth=18, max_boxes=1000000)
    assert result.status is Status.VALID


def test_above_reach_two_circle_gap_never_valid():
    circles = [CircleSpec(F(0), F(0), F(2)), CircleSpec(F(21, 5), F(0), F(2))]  # boundary gap 1/5, reach 1/10
    atlas, delta = build(circles, 7)
    result = certify_dcsd(atlas, F(1, 5), delta_loc=delta, max_depth=20, max_boxes=1000000)
    assert result.status is not Status.VALID


def test_exact_equality_is_allowed_to_be_unknown():
    circles = [CircleSpec(F(0), F(0), F(2)), CircleSpec(F(6), F(0), F(2))]  # gap 2, reach 1
    atlas, delta = build(circles, 8)
    result = certify_dcsd(atlas, F(1), delta_loc=delta, max_depth=12, max_boxes=200000)
    assert result.status in {Status.VALID, Status.UNKNOWN}
