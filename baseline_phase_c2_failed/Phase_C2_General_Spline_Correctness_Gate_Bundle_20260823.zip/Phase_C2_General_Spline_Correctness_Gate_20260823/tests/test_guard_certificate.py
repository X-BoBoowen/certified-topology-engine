from fractions import Fraction as F

from phase_c2_general_spline.cell_complex import Cell, ExactRectangle, PiecewisePolynomialField2D
from phase_c2_general_spline.frame_dictionary import Frame
from phase_c2_general_spline.implicit_guard import GuardSeed, certify_guard
from phase_c2_general_spline.interval import RationalInterval as I
from phase_c2_general_spline.rational_polynomial import RationalPolynomial2D as P
from phase_c2_general_spline.status import Status


def circle_field():
    p = P({(2, 0): F(1), (0, 2): F(1), (0, 0): F(-1)})
    domain = ExactRectangle(F(-2), F(2), F(-2), F(2))
    field = PiecewisePolynomialField2D(domain, [Cell("all", domain, p)])
    assert field.validate().status is Status.VALID
    return field


def test_certified_guard_for_right_circle_arc():
    seed = GuardSeed(
        guard_id="g",
        ox=F(1), oy=F(0),
        frame=Frame.from_normal(1, 0),
        guard_s=I(F(-1, 4), F(1, 4)),
        guard_v=I(F(-1, 2), F(1, 2)),
        owner_s=I(F(-1, 8), F(1, 8)),
    )
    result = certify_guard(circle_field(), seed)
    assert result.status is Status.VALID
    assert result.data["certificate"].slope_bound <= F(1, 2)


def test_guard_rejects_two_branches_in_same_normal_strip():
    seed = GuardSeed(
        guard_id="bad",
        ox=F(0), oy=F(0),
        frame=Frame.from_normal(1, 0),
        guard_s=I(F(-1, 4), F(1, 4)),
        guard_v=I(F(-3, 2), F(3, 2)),
        owner_s=I(F(-1, 8), F(1, 8)),
    )
    assert certify_guard(circle_field(), seed).status is not Status.VALID
