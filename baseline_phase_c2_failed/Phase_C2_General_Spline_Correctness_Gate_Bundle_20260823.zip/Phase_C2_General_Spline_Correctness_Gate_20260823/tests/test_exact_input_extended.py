from decimal import Decimal
from fractions import Fraction as F

import pytest

from phase_c2_general_spline.cell_complex import ExactRectangle
from phase_c2_general_spline.exact_types import ExactInputError
from phase_c2_general_spline.frame_dictionary import Frame
from phase_c2_general_spline.interval import RationalInterval
from phase_c2_general_spline.rational_polynomial import RationalPolynomial2D


class IntSubclass(int):
    pass


@pytest.mark.parametrize("value", [0.25, Decimal("0.25"), True, IntSubclass(1), "1/4"])
def test_polynomial_coefficients_reject_noncontract_types(value):
    with pytest.raises(ExactInputError):
        RationalPolynomial2D({(0, 0): value})


def test_rectangle_interval_and_frame_reject_float_or_bool_components():
    with pytest.raises(ExactInputError):
        ExactRectangle(0.0, F(1), F(0), F(1))
    with pytest.raises(ExactInputError):
        RationalInterval(F(0), 1.0)
    with pytest.raises(ExactInputError):
        Frame.from_normal(True, 0)
