from fractions import Fraction as F

from phase_c2_general_spline.delta_loc import certify_delta_loc
from phase_c2_general_spline.scenarios import CircleSpec, circle_product_field, circle_proposals
from phase_c2_general_spline.spline_atlas import AtlasBuilder
from phase_c2_general_spline.status import Status


def test_general_delta_loc_is_positive_for_strict_circle_atlas():
    circles = [CircleSpec(F(0), F(0), F(2))]
    field = circle_product_field(circles, F(4))
    atlas_result = AtlasBuilder(max_cover_depth=9, max_cover_boxes=20000).build(field, proposals=circle_proposals(circles))
    assert atlas_result.status is Status.VALID
    result = certify_delta_loc(atlas_result.data["atlas"], max_depth=12, max_boxes=200000)
    assert result.status is Status.VALID
    assert result.data["delta_loc"] > 0


def test_delta_loc_budget_failure_is_unknown():
    circles = [CircleSpec(F(0), F(0), F(2))]
    field = circle_product_field(circles, F(4))
    atlas = AtlasBuilder(max_cover_depth=9, max_cover_boxes=20000).build(field, proposals=circle_proposals(circles)).data["atlas"]
    assert certify_delta_loc(atlas, max_depth=0, max_boxes=1).status is Status.UNKNOWN
