from fractions import Fraction as F

from phase_c2_general_spline.spline_atlas import AtlasBuilder
from phase_c2_general_spline.status import Status
from tests.helpers import single_circle


def test_general_atlas_covers_single_circle_with_runtime_certificate():
    field, proposals = single_circle(radius=2)
    result = AtlasBuilder(max_cover_depth=8, max_cover_boxes=10000).build(field, proposals=proposals)
    assert result.status is Status.VALID
    atlas = result.data["atlas"]
    assert atlas.patches
    assert atlas.coverage_unresolved == 0
    assert atlas.loop_cycles == ((0,),) or len(atlas.loop_cycles) == 1


def test_atlas_budget_exhaustion_is_unknown_not_valid():
    field, proposals = single_circle(radius=2)
    result = AtlasBuilder(max_cover_depth=0, max_cover_boxes=1).build(field, proposals=proposals)
    assert result.status is Status.UNKNOWN
