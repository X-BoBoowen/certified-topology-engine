from fractions import Fraction as F

from phase_c2_general_spline.cell_complex import Cell, ExactRectangle, PiecewisePolynomialField2D
from phase_c2_general_spline.frame_dictionary import Frame
from phase_c2_general_spline.implicit_guard import GuardSeed, certify_guard
from phase_c2_general_spline.implicit_patch import ImplicitPatchEvaluator
from phase_c2_general_spline.interval import RationalInterval as I
from phase_c2_general_spline.rational_polynomial import RationalPolynomial2D as P
from phase_c2_general_spline.status import Status


def make_patch():
    p = P({(2, 0): F(1), (0, 2): F(1), (0, 0): F(-1)})
    domain = ExactRectangle(F(-2), F(2), F(-2), F(2))
    field = PiecewisePolynomialField2D(domain, [Cell("all", domain, p)])
    assert field.validate().status is Status.VALID
    seed = GuardSeed("g", F(1), F(0), Frame.from_normal(1, 0), I(F(-1, 4), F(1, 4)), I(F(-1, 2), F(1, 2)), I(F(-1, 8), F(1, 8)))
    cert = certify_guard(field, seed).data["certificate"]
    return ImplicitPatchEvaluator(cert)


def test_root_enclosure_contains_exact_rational_circle_point():
    patch = make_patch()
    t = F(1, 10)
    x = (1 - t * t) / (1 + t * t)
    y = 2 * t / (1 + t * t)
    v = x - 1
    bracket = patch.root_enclosure(I.point(y), steps=16)
    assert bracket.contains(v)


def test_gamma_and_derivative_enclosures_are_finite_and_nonzero():
    patch = make_patch()
    s = I(F(-1, 16), F(1, 16))
    gamma = patch.gamma(s)
    tangent = patch.gamma_prime(s)
    second = patch.gamma_second(s)
    assert gamma.x.width >= 0 and gamma.y.width >= 0
    assert not (tangent.x.contains_zero() and tangent.y.contains_zero())
    assert second.x.width >= 0 and second.y.width >= 0
