from fractions import Fraction as F

from phase_c2_general_spline.cell_complex import Cell, ExactRectangle, PiecewisePolynomialField2D
from phase_c2_general_spline.general_reach_engine import GeneralReachEngine
from phase_c2_general_spline.rational_polynomial import RationalPolynomial2D as P
from phase_c2_general_spline.status import Status


def one_cell(p, radius=2):
    domain = ExactRectangle(F(-radius), F(radius), F(-radius), F(radius))
    return PiecewisePolynomialField2D(domain, [Cell("all", domain, p)])


def test_squared_circle_singular_zero_set_never_valid():
    g = P({(2, 0): F(1), (0, 2): F(1), (0, 0): F(-1)})
    result = GeneralReachEngine().certify(one_cell(g * g), F(1, 2), proposals=())
    assert result.status is not Status.VALID


def test_crossing_field_never_valid():
    xy = P({(1, 1): F(1)})
    result = GeneralReachEngine().certify(one_cell(xy), F(1, 10), proposals=())
    assert result.status is not Status.VALID


def test_boundary_zero_is_not_accepted():
    p = P({(1, 0): F(1), (0, 0): F(-2)})
    field = one_cell(p, radius=2)
    assert field.validate().status is not Status.VALID
