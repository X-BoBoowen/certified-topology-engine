from fractions import Fraction as F

from phase_c2_general_spline.cell_complex import Cell, ExactRectangle, PiecewisePolynomialField2D
from phase_c2_general_spline.rational_polynomial import RationalPolynomial2D as P
from phase_c2_general_spline.scenarios import CircleSpec, circle_product_field, circle_proposals


def single_circle(radius=2, domain_radius=4, *, grid_x=(), grid_y=()):
    circles = [CircleSpec(F(0), F(0), F(radius))]
    field = circle_product_field(circles, F(domain_radius), grid_x=tuple(F(v) for v in grid_x), grid_y=tuple(F(v) for v in grid_y))
    return field, circle_proposals(circles)
