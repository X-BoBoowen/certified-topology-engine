from pathlib import Path

from phase_c2_general_spline.suite_support import run_c1_differential


def test_all_22_frozen_circle_scenarios_have_no_general_false_valid(tmp_path):
    root = Path(__file__).resolve().parents[1]
    result = run_c1_differential(root / "results" / "c1_captured_calls.json", tmp_path)
    assert result["scenario_count"] == 22
    assert result["false_valid_count"] == 0
    assert result["general_valid_count"] > 0
