from fractions import Fraction as F

from phase_c2_general_spline.cell_complex import Cell, ExactRectangle, PiecewisePolynomialField2D
from phase_c2_general_spline.rational_polynomial import RationalPolynomial2D as P
from phase_c2_general_spline.status import Status


def make_field(right):
    domain = ExactRectangle(F(-2), F(2), F(-2), F(2))
    left = P({(2, 0): F(1), (0, 2): F(1), (0, 0): F(-1)})
    return PiecewisePolynomialField2D(domain, [
        Cell("L", ExactRectangle(F(-2), F(0), F(-2), F(2)), left),
        Cell("R", ExactRectangle(F(0), F(2), F(-2), F(2)), right),
    ])


def test_exact_c2_interface_passes_identical_pieces():
    p = P({(2, 0): F(1), (0, 2): F(1), (0, 0): F(-1)})
    assert make_field(p).validate().status is Status.VALID


def test_c0_but_not_c1_interface_is_invalid():
    # Difference x vanishes at x=0, but x derivative does not.
    base = P({(2, 0): F(1), (0, 2): F(1), (0, 0): F(-1)})
    bad = base + P({(1, 0): F(1)})
    assert make_field(bad).validate().status is Status.INPUT_INVALID


def test_c1_but_not_c2_interface_is_invalid():
    # Difference x^2 has zero value and first derivative at x=0, but nonzero xx derivative.
    base = P({(2, 0): F(1), (0, 2): F(1), (0, 0): F(-1)})
    bad = base + P({(2, 0): F(1)})
    assert make_field(bad).validate().status is Status.INPUT_INVALID
