# General Local-Diagonal Exclusion and δ_loc Soundness

For a graph patch

\[
\gamma(s)=o+s e+f(s)n,
\qquad |f'(s)|<1,
\]

any nonzero chord within the same guard satisfies

\[
(\gamma(t)-\gamma(s))\cdot\gamma'(s)
=(t-s)\left(1+q_{s,t}f'(s)\right)\ne0,
\]

because \(|q_{s,t}|<1\). Thus a same-guard pair cannot be doubly critical.

For every owner patch the implementation exhaustively compares it with every patch not certified local by a common guard. Parameter rectangles are bisected with exact rational endpoints. A distance leaf is accepted only when the exact interval lower bound on squared distance is strictly positive. If any leaf remains unresolved, the complete `delta_loc` computation returns `UNKNOWN`.

Let \(d_*^2\) be the minimum of all accepted nonlocal squared-distance lower bounds. The engine computes a dyadic rational \(q\) with \(q^2\le d_*^2\), then returns

\[
\delta_{\rm loc}=q/2>0.
\]

Every pair of curve points at distance below \(\delta_{\rm loc}\) must lie in a common certified graph guard and therefore cannot be doubly critical.

This implementation uses a finite patch cover rather than an abstract set complement. Extra patch overlap can only reduce the certified lower bound or force `UNKNOWN`; it cannot produce a false positive.
