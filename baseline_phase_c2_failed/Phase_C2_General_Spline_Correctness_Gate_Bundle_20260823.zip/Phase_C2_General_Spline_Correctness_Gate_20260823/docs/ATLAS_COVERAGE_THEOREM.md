# Atlas Coverage Theorem Implemented by the Reference Engine

Let \(F\) satisfy the exact field contract. A guard candidate is accepted only when exact interval evaluation proves:

1. a strictly positive normal derivative on the complete guard;
2. a tangent-to-normal derivative ratio at most \(1/2\);
3. strictly opposite signs on the two normal faces;
4. strict containment of the owner parameter interval in the guard interval;
5. containment of the guard in the certified domain.

These predicates imply that the zero set in the guard is one and only one implicit graph branch.

The coverage verifier recursively partitions every input cell by exact rational cover-preserving bisection. Each leaf is classified as either:

- zero-free, because its exact interval image excludes zero; or
- guard-covered, because the complete spatial leaf lies in the owner slab of an accepted unique-branch guard.

No leaf may remain unclassified. If the depth or box budget is reached, atlas construction returns `UNKNOWN`.

Therefore, whenever the builder returns `VALID_ATLAS`, every point of \(F^{-1}(0)\) is contained in at least one accepted implicit patch. Cell edges and corners are not perturbed: a guard crossing them evaluates every incident polynomial piece and takes the exact interval hull.

## Ownership and loop limitation

For the implemented synthetic suites, exact circle proposal metadata supplies a cyclic candidate order. The implementation does not trust that order as a geometry certificate: every consecutive pair must be jointly contained in an accepted common guard, and the independent field-level zero-box coverage must close.

However, automatic extraction of the cyclic order from an arbitrary piecewise-polynomial field is not implemented. Consequently this module is a sound verifier for a finite proposed atlas, not yet a complete field-only general spline atlas constructor.
