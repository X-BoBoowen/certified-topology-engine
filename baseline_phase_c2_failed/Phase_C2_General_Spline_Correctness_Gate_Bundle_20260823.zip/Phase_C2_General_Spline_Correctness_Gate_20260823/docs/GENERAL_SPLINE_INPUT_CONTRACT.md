# General Piecewise-Polynomial Input Contract

## Certified numeric boundary

Every number used by a certificate predicate must be either:

- an exact `fractions.Fraction`; or
- a non-boolean builtin `int`, immediately converted to `Fraction`.

The runtime rejects `float`, `Decimal`, `bool`, strings, NumPy scalars, numeric subclasses, custom coercible objects, and implicit `__float__`, `__int__`, or `__index__` conversion. Textual rational input is handled only by the explicit `parse_rational` adapter.

## Domain and cells

A `PiecewisePolynomialField2D` contains an exact rational rectangle

\[
\Omega=[x_0,x_1]\times[y_0,y_1]
\]

and a finite structured axis-aligned rational cell complex. The induced elementary rectangles must be covered exactly once. Gaps and positive-area overlaps are `INPUT_INVALID`.

Each cell stores a sparse polynomial in \(\mathbb Q[x,y]\). Exact differentiation through order two is available.

## C² interfaces

For every shared vertical or horizontal edge, the implementation restricts the difference of the two incident polynomial pieces and each of

\[
F_x,F_y,F_{xx},F_{xy},F_{yy}
\]

to the complete edge. Every resulting univariate coefficient must vanish exactly. Finite sampling is not used.

## Compact zero-set boundary condition

Every domain-boundary edge is evaluated using exact rational interval arithmetic. The contract closes only when zero is excluded on all boundary edges. If the natural enclosure contains zero, the current reference implementation returns `UNKNOWN`; it never treats the boundary as zero-free heuristically.

## Current completeness boundary

The field representation is general. The present atlas builder is proof-carrying and proposal-assisted: guard candidates may be supplied, but every guard, every multi-cell derivative hull, and the complete zero-box coverage are re-certified from the field. A field-only, candidate-free loop discovery algorithm is not yet implemented. This is the decisive reason for the Phase C.2 `PIVOT` verdict.
