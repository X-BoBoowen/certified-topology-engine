# Rational Frame Dictionary Proof

Use the four undirected normal directions

\[
(1,0),\ (1,1),\ (0,1),\ (-1,1),
\]

with the orthogonal tangent vector obtained by a 90-degree integer rotation. Their unoriented angles are spaced by \(\pi/4\). For any nonzero vector \(g\), one dictionary normal has angular difference \(\theta\le\pi/8\). Because the tangent and normal have equal norm,

\[
\frac{|g\cdot e|}{|g\cdot n|}=|\tan\theta|
\le \tan(\pi/8)=\sqrt2-1<\frac12.
\]

The implementation does not evaluate \(\sqrt2\): it enumerates the four exact integer frames and checks the exact rational inequality

\[
2|g\cdot e|\le |g\cdot n|.
\]

One frame must pass by the angular argument above. Orientation is flipped so that \(g\cdot n>0\). For an interval gradient field, a guard is accepted only after the stronger interval inequality is directly certified on the whole guard.
