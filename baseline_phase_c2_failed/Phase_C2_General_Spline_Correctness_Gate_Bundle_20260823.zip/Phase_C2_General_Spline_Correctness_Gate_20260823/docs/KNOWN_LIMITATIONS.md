# Known Limitations

1. **Proposal-assisted atlas.** The exact field adapter is general, but successful atlas construction currently needs finite guard/loop candidates. Circle candidates are generated analytically and then independently verified against the piecewise field. A field-only loop discovery algorithm is not implemented.
2. **No certified BVH.** Every unordered patch pair is enumerated. This is deliberate for correctness, but quadratic scaling is substantial.
3. **No real images.** The engine has not been evaluated on medical or other visual data.
4. **No raw-mask compiler.** There is no production raster/logit-to-spline compiler.
5. **No XOR area or conformal modules.** Phase C.2 contains only the reach engine.
6. **Equality incompleteness.** Exact or near equality may remain `UNKNOWN` indefinitely.
7. **Natural interval overestimation.** Valid fields may return `UNKNOWN`, especially across many cells or high-degree factors.
8. **Proof replay is structural.** The included replay tool checks log integrity and stage closure; a fully independent arithmetic re-execution verifier remains future work.
9. **Synthetic success is not practical feasibility.** Passing circle and knot-transformed suites does not establish useful runtime on general splines.

These limitations require `PIVOT`, not `READY FOR INDEPENDENT GENERAL-SPLINE AUDIT`.
