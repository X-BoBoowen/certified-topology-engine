# Scenario–Test Mapping

## Phase C.1 differential scenarios

| Index | Frozen scenario | C.1 status | General status | Analytic-safe at r0 | False VALID |
|---:|---|---|---|---:|---:|

## Piecewise-C² knot/cell suite

| Scenario | Expected semantics | Actual | Passed |
|---|---|---|---:|

## Pytest mapping

- `test_exact_input*.py`: exact numeric boundary for field, coefficients, rectangles, frames, intervals, and `r0`.
- `test_cell_complex.py`, `test_c2_interfaces.py`: no gaps/overlaps and exact C² interface identities.
- `test_guard_certificate.py`, `test_implicit_patch.py`: unique graph guards and certified implicit position/derivatives.
- `test_atlas_coverage.py`, `test_knot_and_corner.py`, `test_loop_ownership.py`: field-level coverage and proposal-assisted loop certificates.
- `test_delta_loc.py`: positive nonlocal separation and failure-to-UNKNOWN.
- `test_pair_cover.py`: exhaustive DCSD strict/equality/above-reach behavior.
- `test_curvature.py`: exact curvature inequality closure.
- `test_general_reach_engine.py`: sole final VALID gate and exact `r0` boundary.
- `test_circle_differential.py`: all 22 frozen circle calls.
- `test_piecewise_spline_suite.py`: genuine C² knot/corner fields.
- `test_adversarial_fields.py`: singular, crossing, and boundary-contact fields.
- `test_property_suite.py`: exact interval inclusion regression.
- `test_proof_log_replay.py`: proof-log integrity and tamper detection.
