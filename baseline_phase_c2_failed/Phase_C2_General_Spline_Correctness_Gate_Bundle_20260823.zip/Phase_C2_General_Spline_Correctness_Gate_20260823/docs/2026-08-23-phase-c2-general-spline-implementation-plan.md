# Phase C.2 General Piecewise-Polynomial Reach Engine Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a correctness-first exact-rational reference engine for certifying `VALID => reach(F^{-1}(0)) >= r0` on finite C² piecewise-polynomial planar fields, without BVH or sampled geometry.

**Architecture:** The implementation is a sound semi-decision procedure. It validates a rational rectangular cell complex and exact C² polynomial compatibility, constructs a finite certified guard/owner atlas by adaptive rational subdivision, computes a certified local-diagonal exclusion radius, exhaustively checks every unordered patch pair using rational interval enclosures of distance and doubly-critical equations, and emits `VALID` only when every proof obligation closes. Any incomplete numerical or combinatorial obligation returns `UNKNOWN`.

**Tech Stack:** Python 3.11+, `fractions.Fraction`, standard library only for certificate predicates; `pytest` for tests; optional `sympy` only in offline reference generators, never in the `VALID` decision path.

**Spec:** User-provided “Phase C.2：General Spline Atlas 与 General δ_loc Correctness Gate”.

## Global Constraints

- Phase C.1 source and API are immutable; only hashes and differential invocation are allowed.
- Certified inputs accept only builtin `int` (not `bool`) and exact `fractions.Fraction`.
- No `float`, `Decimal`, NumPy scalar, numeric subclasses, or implicit coercion in certificate predicates.
- No BVH, KD-tree, sampled boundary, raster medial axis, ordinary floating-point roots, or heuristic pruning.
- Every unresolved proof obligation returns `UNKNOWN`.
- All unordered owner-patch pairs are exhaustively enumerated.
- Tests precede implementation and red/green logs are retained.

---

### Task 1: Frozen baseline and exact numeric kernel

**Files:**
- Create: `src/phase_c2_general_spline/exact_types.py`
- Create: `src/phase_c2_general_spline/interval.py`
- Test: `tests/test_exact_input.py`
- Test: `tests/test_interval.py`

**Interfaces:**
- Produces `require_fraction`, `parse_rational`, `RationalInterval` and exact arithmetic used by all later modules.

- [ ] Write tests rejecting unsupported numeric types and checking exact interval inclusion.
- [ ] Run tests and save failing output.
- [ ] Implement minimal exact validators and intervals.
- [ ] Run tests and save passing output.

### Task 2: Exact rational polynomials

**Files:**
- Create: `src/phase_c2_general_spline/rational_polynomial.py`
- Create: `src/phase_c2_general_spline/interval_polynomial.py`
- Test: `tests/test_polynomial.py`
- Test: `tests/test_interval_inclusion.py`

**Interfaces:**
- Produces exact differentiation, transformed directional derivatives, edge restrictions, exact point evaluation, and inclusion interval evaluation.

- [ ] Write derivative, edge-identity, and randomized exact-reference inclusion tests.
- [ ] Verify tests fail.
- [ ] Implement sparse rational bivariate polynomials and interval evaluation.
- [ ] Verify tests pass.

### Task 3: Rectangular cell complex and field contract

**Files:**
- Create: `src/phase_c2_general_spline/cell_complex.py`
- Create: `src/phase_c2_general_spline/field.py`
- Test: `tests/test_cell_complex.py`
- Test: `tests/test_c2_interfaces.py`
- Test: `tests/test_adversarial_fields.py`

**Interfaces:**
- Produces `PiecewisePolynomialField2D.validate()` and exact incident-cell lookup.

- [ ] Write failures for gaps, overlaps, non-C² interfaces, boundary zeros, floats, and missing cells.
- [ ] Verify failures.
- [ ] Implement exact structured-grid validation, C² edge polynomial identities, and zero-free boundary certification.
- [ ] Verify tests pass.

### Task 4: Rational frame dictionary

**Files:**
- Create: `src/phase_c2_general_spline/frame_dictionary.py`
- Test: `tests/test_frame_dictionary.py`
- Create: `docs/RATIONAL_FRAME_DICTIONARY_PROOF.md`

**Interfaces:**
- Produces exact frames and a finite coverage selector with ratio at most 1/2.

- [ ] Write exhaustive rational direction tests.
- [ ] Verify failure.
- [ ] Implement frame selector and proof document.
- [ ] Verify pass.

### Task 5: Certified guards and implicit patch evaluator

**Files:**
- Create: `src/phase_c2_general_spline/implicit_guard.py`
- Create: `src/phase_c2_general_spline/implicit_patch.py`
- Test: `tests/test_guard_certificate.py`
- Test: `tests/test_implicit_patch.py`

**Interfaces:**
- Produces guard certificates, uniform implicit-root brackets, and interval enclosures of γ, γ′, γ″.

- [ ] Write strict circle, knot-crossing, equality, and invalid multi-branch guard tests.
- [ ] Verify failure.
- [ ] Implement multi-cell interval hulls, monotonicity/slope/face-sign checks, and root interval refinement.
- [ ] Verify pass.

### Task 6: Atlas coverage and loop ownership

**Files:**
- Create: `src/phase_c2_general_spline/spline_atlas.py`
- Create: `src/phase_c2_general_spline/loop_ownership.py`
- Test: `tests/test_atlas_coverage.py`
- Test: `tests/test_knot_and_corner.py`
- Test: `tests/test_loop_ownership.py`
- Create: `docs/ATLAS_COVERAGE_THEOREM.md`

**Interfaces:**
- Produces a finite atlas, coverage leaf proof, owner/guard relations, and certified loop cycles.

- [ ] Write circle, multi-loop, knot, corner, seam, singular, and budget-exhaustion tests.
- [ ] Verify failure.
- [ ] Implement adaptive exact box cover, guard generation, half-open owner convention, endpoint matching, and cycle validation.
- [ ] Verify pass.

### Task 7: General δ_loc certificate

**Files:**
- Create: `src/phase_c2_general_spline/delta_loc.py`
- Test: `tests/test_delta_loc.py`
- Create: `docs/DELTA_LOC_SOUNDNESS.md`

**Interfaces:**
- Produces a strict rational lower bound δ_loc and complement-cover proof records.

- [ ] Write strict, seam, nested-loop, near-bottleneck, equality, and unresolved tests.
- [ ] Verify failure.
- [ ] Implement complement patch cover and exhaustive rational interval distance minimization.
- [ ] Verify pass.

### Task 8: Exhaustive DCSD and curvature solvers

**Files:**
- Create: `src/phase_c2_general_spline/general_pair_solver.py`
- Create: `src/phase_c2_general_spline/curvature_certificate.py`
- Test: `tests/test_pair_cover.py`
- Test: `tests/test_curvature.py`

**Interfaces:**
- Produces exhaustive unordered-pair proof and certified curvature upper bound.

- [ ] Write strict-margin, equality, above-reach, nonisolated-family, and max-budget tests.
- [ ] Verify failure.
- [ ] Implement only common-guard, distance, G1, and G2 pruning with cover-preserving bisection.
- [ ] Verify pass.

### Task 9: Final reach engine and replayable proof logs

**Files:**
- Create: `src/phase_c2_general_spline/general_reach_engine.py`
- Create: `src/phase_c2_general_spline/proof_log.py`
- Test: `tests/test_general_reach_engine.py`
- Create: `docs/GENERAL_REACH_SOUNDNESS.md`

**Interfaces:**
- Produces the sole `Status.VALID` construction point and JSON proof logs.

- [ ] Write tests proving unresolved/invalid paths cannot become VALID.
- [ ] Verify failure.
- [ ] Implement final gate composition and replay verifier.
- [ ] Verify pass.

### Task 10: Differential and adversarial suites

**Files:**
- Create: `src/phase_c2_general_spline/scenarios.py`
- Create: `run_general_suite.py`
- Create: `run_property_suite.py`
- Test: `tests/test_circle_differential.py`
- Test: `tests/test_piecewise_spline_suite.py`
- Test: `tests/test_property_suite.py`

**Interfaces:**
- Produces 22 circle differential results, knot/cell scenarios, invalid fields, and at least 100,000 exact inclusion checks.

- [ ] Extract Phase C.1 scenario definitions without modifying baseline.
- [ ] Write differential tests and verify initial failure.
- [ ] Implement exact global-circle and positive C² knot-factor field generators.
- [ ] Run all suites and save JSON/logs.

### Task 11: Documentation, manifest, and immutable packaging

**Files:**
- Create: `README.md`
- Create: `docs/GENERAL_SPLINE_INPUT_CONTRACT.md`
- Create: `docs/KNOWN_LIMITATIONS.md`
- Create: `docs/SCENARIO_TEST_MAPPING.md`
- Create: `ENVIRONMENT.txt`
- Create: `requirements.txt`
- Create: `MANIFEST.json`
- Create: `SHA256SUMS.txt`
- Create: inner prototype ZIP and final outer ZIP.

**Interfaces:**
- Produces the complete independent-audit artifact.

- [ ] Run `py_compile`, full pytest, suites, proof-log replay, float-path scan, and baseline hash comparison.
- [ ] Record complete outputs.
- [ ] Generate manifests and hashes.
- [ ] Re-extract final ZIP and rerun all checks.
- [ ] Report only evidence-supported verdict.
