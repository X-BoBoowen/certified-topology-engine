# General Reach Soundness Theorem

The sole construction point for `Status.VALID` is `GeneralReachEngine.certify`.

Assume the runtime proof log records `VALID` for all of the following stages:

1. exact field and cell-complex validation;
2. exact C² interface identities;
3. zero-free domain boundary;
4. finite accepted guard atlas and complete zero-box coverage;
5. certified positive `delta_loc`;
6. certified curvature inequality \(|\kappa|\le1/r_0\) on every patch;
7. exhaustive enumeration of every unordered nonlocal patch pair;
8. cover-preserving parameter subdivision;
9. sound pruning of every leaf by common-guard locality, distance \(\ge2r_0\), \(0\notin G_1\), or \(0\notin G_2\);
10. no unresolved parameter box;
11. exact rational or outward-containing interval arithmetic throughout.

If a true doubly-critical pair of distance below \(2r_0\) existed, atlas coverage would place both points in some enumerated patch pair. Local pairs are impossible by the graph-chord lemma. A nonlocal pair survives every sound pruning predicate and every cover-preserving bisection, contradicting the absence of unresolved leaves. Hence

\[
\operatorname{DCSD}(\Gamma)\ge2r_0.
\]

Combining this with the certified curvature inequality and the accepted reach/thickness characterization yields

\[
\operatorname{reach}(\Gamma)\ge r_0.
\]

The theorem is conditional on the runtime atlas proof. The present implementation does not yet construct such an atlas from an arbitrary field without proposal candidates; it returns `UNKNOWN` in that case.
