from __future__ import annotations

from fractions import Fraction
import json
from pathlib import Path
from typing import Any

from .exact_types import parse_rational
from .general_reach_engine import GeneralReachEngine
from .proof_log import ReachProofLog
from .scenarios import CircleSpec, circle_product_field, circle_proposals
from .status import Status


def _parse_q(value: Any) -> Fraction:
    if type(value) is not str:
        raise TypeError("captured value is not exact rational text")
    return parse_rational(value)


def load_c1_calls(path: str | Path) -> list[dict]:
    calls = json.loads(Path(path).read_text(encoding="utf-8"))
    if len(calls) != 22:
        raise RuntimeError(f"expected exactly 22 Phase C.1 suite calls, found {len(calls)}")
    return calls


def circle_link_contract(circles: list[CircleSpec]) -> bool:
    if not circles:
        return False
    for i, a in enumerate(circles):
        for b in circles[i + 1 :]:
            dx, dy = a.cx - b.cx, a.cy - b.cy
            d2 = dx * dx + dy * dy
            sum2 = (a.radius + b.radius) ** 2
            diff2 = (abs(a.radius - b.radius)) ** 2
            if not (d2 > sum2 or d2 < diff2):
                return False
    return True


def analytic_reach_ge(circles: list[CircleSpec], r0: Fraction) -> bool:
    if not circle_link_contract(circles) or any(c.radius < r0 for c in circles):
        return False
    two = 2 * r0
    for i, a in enumerate(circles):
        for b in circles[i + 1 :]:
            dx, dy = a.cx - b.cx, a.cy - b.cy
            d2 = dx * dx + dy * dy
            if d2 > (a.radius + b.radius) ** 2:
                required = a.radius + b.radius + two
                if d2 < required * required:
                    return False
            else:
                clearance = abs(a.radius - b.radius) - two
                if clearance < 0 or d2 > clearance * clearance:
                    return False
    return True


def _domain_radius(circles: list[CircleSpec]) -> Fraction:
    extent = max(max(abs(c.cx), abs(c.cy)) + c.radius for c in circles)
    return extent + 3


def run_c1_differential(calls_path: str | Path, proof_dir: str | Path | None = None) -> dict:
    calls = load_c1_calls(calls_path)
    proof_path = Path(proof_dir) if proof_dir is not None else None
    if proof_path is not None:
        proof_path.mkdir(parents=True, exist_ok=True)
    rows = []
    false_valid = 0
    general_valid = 0
    for item in calls:
        unsupported = not isinstance(item.get("r0"), str) or any(
            not isinstance(c.get("cx"), str) or not isinstance(c.get("cy"), str) or not isinstance(c.get("radius"), str)
            for c in item.get("circles", [])
        )
        if unsupported:
            rows.append({**item, "general_status": "INPUT_INVALID", "analytic_safe": False, "false_valid": False})
            continue
        circles = [CircleSpec(_parse_q(c["cx"]), _parse_q(c["cy"]), _parse_q(c["radius"])) for c in item["circles"]]
        r0 = _parse_q(item["r0"])
        if not circle_link_contract(circles):
            rows.append({**item, "general_status": "INPUT_INVALID", "analytic_safe": False, "false_valid": False})
            continue
        field = circle_product_field(circles, _domain_radius(circles))
        engine = GeneralReachEngine(
            atlas_depth=11,
            atlas_boxes=120000,
            delta_depth=14,
            delta_boxes=1200000,
            curvature_depth=12,
            curvature_boxes=800000,
            pair_depth=20,
            pair_boxes=2000000,
        )
        result = engine.certify(field, r0, proposals=circle_proposals(circles, pieces_per_quarter=8))
        safe = analytic_reach_ge(circles, r0)
        is_false = result.status is Status.VALID and not safe
        false_valid += int(is_false)
        general_valid += int(result.status is Status.VALID)
        if proof_path is not None:
            result.data["proof_log"].write(proof_path / f"c1_diff_{item['call_index']:02d}.json")
        rows.append({
            **item,
            "general_status": result.status.value,
            "general_reason": result.reason,
            "analytic_safe": safe,
            "false_valid": is_false,
        })
    return {
        "scenario_count": len(rows),
        "general_valid_count": general_valid,
        "false_valid_count": false_valid,
        "rows": rows,
    }
