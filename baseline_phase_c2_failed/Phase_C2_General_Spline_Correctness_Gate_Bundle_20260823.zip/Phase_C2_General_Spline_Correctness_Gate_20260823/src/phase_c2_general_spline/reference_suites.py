from __future__ import annotations

from fractions import Fraction as F
from pathlib import Path
import json

from .general_reach_engine import GeneralReachEngine
from .scenarios import CircleSpec, circle_product_field, circle_proposals
from .status import Status


def knot_scenarios():
    return [
        ("vertical_knot", [CircleSpec(F(0), F(0), F(2))], (F(0),), (), F(3, 2), "VALID"),
        ("horizontal_knot", [CircleSpec(F(0), F(0), F(2))], (), (F(0),), F(3, 2), "VALID"),
        ("knot_corner", [CircleSpec(F(0), F(0), F(2))], (F(0),), (F(2),), F(3, 2), "VALID"),
        ("multi_knots", [CircleSpec(F(0), F(0), F(2))], (F(-1), F(0), F(1)), (F(-1), F(0), F(1)), F(3, 2), "VALID"),
        ("two_loops", [CircleSpec(F(-3), F(0), F(1)), CircleSpec(F(3), F(0), F(1))], (F(0),), (F(0),), F(4, 5), "VALID"),
        ("nested_loops", [CircleSpec(F(0), F(0), F(3)), CircleSpec(F(0), F(0), F(1))], (F(0),), (F(0),), F(9, 10), "VALID"),
        ("near_bottleneck_strict", [CircleSpec(F(0), F(0), F(2)), CircleSpec(F(21, 5), F(0), F(2))], (F(1),), (F(0),), F(9, 100), "VALID"),
        ("near_bottleneck_above", [CircleSpec(F(0), F(0), F(2)), CircleSpec(F(21, 5), F(0), F(2))], (F(1),), (F(0),), F(11, 100), "NOT_VALID"),
        ("equality", [CircleSpec(F(0), F(0), F(2)), CircleSpec(F(6), F(0), F(2))], (F(0),), (F(0),), F(1), "UNKNOWN_ALLOWED"),
    ]


def run_knot_suite(proof_dir: str | Path | None = None):
    proof_path = Path(proof_dir) if proof_dir is not None else None
    if proof_path is not None:
        proof_path.mkdir(parents=True, exist_ok=True)
    rows = []
    failures = 0
    for index, (name, circles, gx, gy, r0, expected) in enumerate(knot_scenarios()):
        extent = max(max(abs(c.cx), abs(c.cy)) + c.radius for c in circles) + 3
        field = circle_product_field(circles, extent, grid_x=gx, grid_y=gy, knot_strength=F(1, 1000))
        result = GeneralReachEngine(
            atlas_depth=11,
            atlas_boxes=150000,
            delta_depth=15,
            delta_boxes=1500000,
            curvature_depth=13,
            curvature_boxes=1000000,
            pair_depth=21,
            pair_boxes=2500000,
        ).certify(field, r0, proposals=circle_proposals(circles, pieces_per_quarter=8))
        passed = (
            (expected == "VALID" and result.status is Status.VALID)
            or (expected == "NOT_VALID" and result.status is not Status.VALID)
            or (expected == "UNKNOWN_ALLOWED" and result.status in {Status.VALID, Status.UNKNOWN})
        )
        failures += int(not passed)
        if proof_path is not None:
            result.data["proof_log"].write(proof_path / f"knot_{index:02d}_{name}.json")
        rows.append({
            "name": name,
            "r0": str(r0),
            "expected": expected,
            "status": result.status.value,
            "reason": result.reason,
            "passed": passed,
            "field_hash": field.field_hash,
        })
    return {"scenario_count": len(rows), "failure_count": failures, "rows": rows}
