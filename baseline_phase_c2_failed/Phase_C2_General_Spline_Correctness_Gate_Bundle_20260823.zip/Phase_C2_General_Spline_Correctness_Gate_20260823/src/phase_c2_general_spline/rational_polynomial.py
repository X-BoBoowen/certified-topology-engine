from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Iterable, Mapping

from .exact_types import ExactInputError, require_fraction
from .interval import RationalInterval as I

Exponent = tuple[int, int]


@dataclass(frozen=True)
class RationalPolynomial2D:
    coefficients: dict[Exponent, Fraction]

    def __init__(self, coefficients: Mapping[Exponent, object] | None = None):
        clean: dict[Exponent, Fraction] = {}
        for exponent, value in (coefficients or {}).items():
            if (
                type(exponent) is not tuple
                or len(exponent) != 2
                or type(exponent[0]) is not int
                or type(exponent[1]) is not int
                or exponent[0] < 0
                or exponent[1] < 0
            ):
                raise ExactInputError(f"invalid exponent {exponent!r}")
            q = require_fraction(value, f"coefficient{exponent}")
            if q:
                clean[exponent] = q
        object.__setattr__(self, "coefficients", clean)

    @staticmethod
    def constant(value: Fraction | int) -> "RationalPolynomial2D":
        q = require_fraction(value, "constant")
        return RationalPolynomial2D({(0, 0): q}) if q else RationalPolynomial2D()

    @property
    def degree_x(self) -> int:
        return max((i for i, _ in self.coefficients), default=-1)

    @property
    def degree_y(self) -> int:
        return max((j for _, j in self.coefficients), default=-1)

    @property
    def total_degree(self) -> int:
        return max((i + j for i, j in self.coefficients), default=-1)

    def is_zero(self) -> bool:
        return not self.coefficients

    def __add__(self, other: object) -> "RationalPolynomial2D":
        rhs = other if type(other) is RationalPolynomial2D else RationalPolynomial2D.constant(require_fraction(other, "polynomial scalar"))
        out = dict(self.coefficients)
        for exponent, value in rhs.coefficients.items():
            out[exponent] = out.get(exponent, Fraction(0)) + value
            if not out[exponent]:
                del out[exponent]
        return RationalPolynomial2D(out)

    __radd__ = __add__

    def __neg__(self) -> "RationalPolynomial2D":
        return RationalPolynomial2D({k: -v for k, v in self.coefficients.items()})

    def __sub__(self, other: object) -> "RationalPolynomial2D":
        return self + (-other if type(other) is RationalPolynomial2D else -require_fraction(other, "polynomial scalar"))

    def __rsub__(self, other: object) -> "RationalPolynomial2D":
        return (-self) + other

    def __mul__(self, other: object) -> "RationalPolynomial2D":
        if type(other) is RationalPolynomial2D:
            out: dict[Exponent, Fraction] = {}
            for (i, j), a in self.coefficients.items():
                for (k, l), b in other.coefficients.items():
                    exponent = (i + k, j + l)
                    out[exponent] = out.get(exponent, Fraction(0)) + a * b
            return RationalPolynomial2D(out)
        scalar = require_fraction(other, "polynomial scalar")
        return RationalPolynomial2D({k: scalar * v for k, v in self.coefficients.items()})

    __rmul__ = __mul__

    def derivative(self, dx_order: int = 0, dy_order: int = 0) -> "RationalPolynomial2D":
        if type(dx_order) is not int or type(dy_order) is not int or dx_order < 0 or dy_order < 0:
            raise ValueError("derivative orders must be nonnegative builtin ints")
        out: dict[Exponent, Fraction] = {}
        for (i, j), value in self.coefficients.items():
            if i < dx_order or j < dy_order:
                continue
            factor = Fraction(1)
            for k in range(dx_order):
                factor *= i - k
            for k in range(dy_order):
                factor *= j - k
            out[(i - dx_order, j - dy_order)] = value * factor
        return RationalPolynomial2D(out)

    def dx(self) -> "RationalPolynomial2D":
        return self.derivative(1, 0)

    def dy(self) -> "RationalPolynomial2D":
        return self.derivative(0, 1)

    def evaluate(self, x: Fraction | int, y: Fraction | int) -> Fraction:
        xx = require_fraction(x, "x")
        yy = require_fraction(y, "y")
        total = Fraction(0)
        for (i, j), value in self.coefficients.items():
            total += value * xx**i * yy**j
        return total

    def evaluate_interval(self, x: I, y: I) -> I:
        total = I.point(0)
        x_powers = {0: I.point(1)}
        y_powers = {0: I.point(1)}
        for i in range(1, self.degree_x + 1):
            x_powers[i] = x_powers[i - 1] * x
        for j in range(1, self.degree_y + 1):
            y_powers[j] = y_powers[j - 1] * y
        for (i, j), value in self.coefficients.items():
            total = total + value * x_powers[i] * y_powers[j]
        return total

    def restrict_x(self, x: Fraction | int) -> dict[int, Fraction]:
        xx = require_fraction(x, "x")
        out: dict[int, Fraction] = {}
        for (i, j), value in self.coefficients.items():
            out[j] = out.get(j, Fraction(0)) + value * xx**i
        return {j: v for j, v in out.items() if v}

    def restrict_y(self, y: Fraction | int) -> dict[int, Fraction]:
        yy = require_fraction(y, "y")
        out: dict[int, Fraction] = {}
        for (i, j), value in self.coefficients.items():
            out[i] = out.get(i, Fraction(0)) + value * yy**j
        return {i: v for i, v in out.items() if v}

    def directional(self, vx: Fraction | int, vy: Fraction | int) -> "RationalPolynomial2D":
        a = require_fraction(vx, "vx")
        b = require_fraction(vy, "vy")
        return a * self.dx() + b * self.dy()

    def compose_affine(
        self,
        ox: Fraction | int,
        oy: Fraction | int,
        ex: Fraction | int,
        ey: Fraction | int,
        nx: Fraction | int,
        ny: Fraction | int,
    ) -> "RationalPolynomial2D":
        """Return P(o + s e + v n), with output variables (s,v)."""
        oxq, oyq = require_fraction(ox, "ox"), require_fraction(oy, "oy")
        exq, eyq = require_fraction(ex, "ex"), require_fraction(ey, "ey")
        nxq, nyq = require_fraction(nx, "nx"), require_fraction(ny, "ny")
        xs = RationalPolynomial2D({(0, 0): oxq, (1, 0): exq, (0, 1): nxq})
        ys = RationalPolynomial2D({(0, 0): oyq, (1, 0): eyq, (0, 1): nyq})
        x_powers = [RationalPolynomial2D.constant(1)]
        y_powers = [RationalPolynomial2D.constant(1)]
        for _ in range(self.degree_x):
            x_powers.append(x_powers[-1] * xs)
        for _ in range(self.degree_y):
            y_powers.append(y_powers[-1] * ys)
        out = RationalPolynomial2D()
        for (i, j), value in self.coefficients.items():
            out = out + value * x_powers[i] * y_powers[j]
        return out
