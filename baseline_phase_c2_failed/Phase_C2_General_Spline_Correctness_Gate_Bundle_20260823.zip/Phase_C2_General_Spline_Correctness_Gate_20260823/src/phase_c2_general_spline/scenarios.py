from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Iterable

from .cell_complex import Cell, ExactRectangle, PiecewisePolynomialField2D
from .exact_types import ExactInputError, require_fraction
from .frame_dictionary import select_frame_for_vector
from .implicit_guard import GuardSeed
from .interval import RationalInterval as I
from .rational_polynomial import RationalPolynomial2D as P


@dataclass(frozen=True, slots=True)
class CircleSpec:
    cx: Fraction
    cy: Fraction
    radius: Fraction

    def __post_init__(self) -> None:
        object.__setattr__(self, "cx", require_fraction(self.cx, "cx"))
        object.__setattr__(self, "cy", require_fraction(self.cy, "cy"))
        object.__setattr__(self, "radius", require_fraction(self.radius, "radius"))
        if self.radius <= 0:
            raise ExactInputError("circle radius must be positive")


@dataclass(frozen=True)
class GuardProposal:
    seed: GuardSeed
    loop_id: int
    order: int
    source: str


def circle_polynomial(circle: CircleSpec) -> P:
    x_minus = P({(1, 0): Fraction(1), (0, 0): -circle.cx})
    y_minus = P({(0, 1): Fraction(1), (0, 0): -circle.cy})
    return x_minus * x_minus + y_minus * y_minus - circle.radius * circle.radius


def _positive_c2_factor(
    x_lo: Fraction,
    y_lo: Fraction,
    grid_x: tuple[Fraction, ...],
    grid_y: tuple[Fraction, ...],
    strength: Fraction,
) -> P:
    factor = P.constant(1)
    x = P({(1, 0): Fraction(1)})
    y = P({(0, 1): Fraction(1)})
    if strength:
        for knot in grid_x:
            if x_lo >= knot:
                term = x - knot
                factor = factor + strength * term * term * term
        for knot in grid_y:
            if y_lo >= knot:
                term = y - knot
                factor = factor + strength * term * term * term
    return factor


def circle_product_field(
    circles: Iterable[CircleSpec],
    domain_radius: Fraction | int,
    *,
    grid_x: tuple[Fraction, ...] = (),
    grid_y: tuple[Fraction, ...] = (),
    knot_strength: Fraction = Fraction(0),
) -> PiecewisePolynomialField2D:
    circle_list = list(circles)
    if not circle_list:
        raise ExactInputError("at least one circle is required")
    radius = require_fraction(domain_radius, "domain_radius")
    strength = require_fraction(knot_strength, "knot_strength")
    if radius <= 0 or strength < 0:
        raise ExactInputError("invalid domain radius or knot strength")
    gx = tuple(sorted({require_fraction(v, "grid_x") for v in grid_x if -radius < require_fraction(v, "grid_x") < radius}))
    gy = tuple(sorted({require_fraction(v, "grid_y") for v in grid_y if -radius < require_fraction(v, "grid_y") < radius}))
    base = P.constant(1)
    for circle in circle_list:
        base = base * circle_polynomial(circle)
    xs = (-radius, *gx, radius)
    ys = (-radius, *gy, radius)
    cells: list[Cell] = []
    for i in range(len(xs) - 1):
        for j in range(len(ys) - 1):
            rect = ExactRectangle(xs[i], xs[i + 1], ys[j], ys[j + 1])
            factor = _positive_c2_factor(rect.x_lo, rect.y_lo, gx, gy, strength)
            cells.append(Cell(f"c_{i}_{j}", rect, factor * base))
    return PiecewisePolynomialField2D(ExactRectangle(-radius, radius, -radius, radius), cells)


def _unit_point(t: Fraction, quarter: int) -> tuple[Fraction, Fraction]:
    den = 1 + t * t
    x = (1 - t * t) / den
    y = 2 * t / den
    q = quarter % 4
    if q == 0:
        return x, y
    if q == 1:
        return -y, x
    if q == 2:
        return -x, -y
    return y, -x


def _frame_coordinates(
    x: Fraction,
    y: Fraction,
    ox: Fraction,
    oy: Fraction,
    ex: int,
    ey: int,
    nx: int,
    ny: int,
) -> tuple[Fraction, Fraction]:
    q = nx * nx + ny * ny
    dx, dy = x - ox, y - oy
    return (Fraction(ex * dx + ey * dy, q), Fraction(nx * dx + ny * dy, q))


def circle_proposals(circles: Iterable[CircleSpec], *, pieces_per_quarter: int = 12) -> list[GuardProposal]:
    if type(pieces_per_quarter) is not int or pieces_per_quarter < 4:
        raise ExactInputError("pieces_per_quarter must be a builtin int >= 4")
    proposals: list[GuardProposal] = []
    for loop_id, circle in enumerate(circles):
        order = 0
        for quarter in range(4):
            for j in range(pieces_per_quarter):
                t0 = Fraction(j, pieces_per_quarter)
                t1 = Fraction(j + 1, pieces_per_quarter)
                tm = (t0 + t1) / 2
                ux, uy = _unit_point(tm, quarter)
                ox = circle.cx + circle.radius * ux
                oy = circle.cy + circle.radius * uy
                frame = select_frame_for_vector(ux, uy)
                points = []
                for t in (t0, (3 * t0 + t1) / 4, tm, (t0 + 3 * t1) / 4, t1):
                    px, py = _unit_point(t, quarter)
                    x = circle.cx + circle.radius * px
                    y = circle.cy + circle.radius * py
                    points.append(_frame_coordinates(x, y, ox, oy, frame.ex, frame.ey, frame.nx, frame.ny))
                s_lo = min(s for s, _ in points)
                s_hi = max(s for s, _ in points)
                width = s_hi - s_lo
                if width <= 0:
                    width = circle.radius / (pieces_per_quarter * 8)
                owner = I(s_lo - width / 3, s_hi + width / 3)
                guard_s = I(s_lo - width, s_hi + width)
                v_half = min(circle.radius, Fraction(1)) / 128
                guard_v = I(-v_half, v_half)
                seed = GuardSeed(
                    f"circle_{loop_id}_{order}",
                    ox,
                    oy,
                    frame,
                    guard_s,
                    guard_v,
                    owner,
                )
                proposals.append(GuardProposal(seed, loop_id, order, "exact_circle_candidate"))
                order += 1
    return proposals
