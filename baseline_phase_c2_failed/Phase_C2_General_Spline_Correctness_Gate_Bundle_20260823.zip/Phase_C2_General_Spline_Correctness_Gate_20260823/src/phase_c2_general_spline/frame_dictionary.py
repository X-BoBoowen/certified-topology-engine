from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction

from .exact_types import ExactInputError, require_fraction


@dataclass(frozen=True, slots=True)
class Frame:
    ex: int
    ey: int
    nx: int
    ny: int

    def __post_init__(self) -> None:
        for name, value in (("ex", self.ex), ("ey", self.ey), ("nx", self.nx), ("ny", self.ny)):
            if type(value) is not int:
                raise ExactInputError(f"{name} must be a builtin int")
        if self.ex * self.nx + self.ey * self.ny != 0:
            raise ExactInputError("frame axes are not orthogonal")
        if self.ex * self.ex + self.ey * self.ey != self.nx * self.nx + self.ny * self.ny:
            raise ExactInputError("frame axes must have equal squared norm")
        if self.nx == 0 and self.ny == 0:
            raise ExactInputError("zero normal")

    @classmethod
    def from_normal(cls, nx: int, ny: int) -> "Frame":
        if type(nx) is not int or type(ny) is not int:
            raise ExactInputError("normal components must be builtin ints")
        return cls(-ny, nx, nx, ny)

    @property
    def norm2(self) -> int:
        return self.nx * self.nx + self.ny * self.ny

    def flipped(self) -> "Frame":
        return Frame(-self.ex, -self.ey, -self.nx, -self.ny)


FRAME_DICTIONARY: tuple[Frame, ...] = (
    Frame.from_normal(1, 0),
    Frame.from_normal(0, 1),
    Frame.from_normal(1, 1),
    Frame.from_normal(1, -1),
)


def select_frame_for_vector(gx: Fraction | int, gy: Fraction | int) -> Frame:
    x = require_fraction(gx, "gx")
    y = require_fraction(gy, "gy")
    if x == 0 and y == 0:
        raise ExactInputError("gradient vector must be nonzero")
    candidates: list[tuple[Fraction, Fraction, int, Frame]] = []
    for index, base in enumerate(FRAME_DICTIONARY):
        de = x * base.ex + y * base.ey
        dn = x * base.nx + y * base.ny
        oriented = base if dn > 0 else base.flipped()
        candidates.append((abs(de) / abs(dn) if dn else Fraction(10**18), -abs(dn), index, oriented))
    ratio, _, _, frame = min(candidates, key=lambda item: (item[0], item[1], item[2]))
    if 2 * abs(x * frame.ex + y * frame.ey) > abs(x * frame.nx + y * frame.ny):
        raise AssertionError("rational frame dictionary coverage invariant violated")
    return frame
