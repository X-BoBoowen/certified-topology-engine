from __future__ import annotations

from dataclasses import dataclass, field
from fractions import Fraction
from collections import deque, defaultdict
from typing import Iterable

from .cell_complex import ExactRectangle, PiecewisePolynomialField2D
from .implicit_guard import GuardCertificate, GuardSeed, certify_guard
from .implicit_patch import ImplicitPatchEvaluator, IntervalVector2
from .interval import RationalInterval as I
from .scenarios import GuardProposal
from .status import Result, Status


@dataclass(frozen=True)
class CertifiedPatch:
    patch_id: int
    loop_id: int
    order: int
    certificate: GuardCertificate
    evaluator: ImplicitPatchEvaluator
    source: str

    @property
    def owner_s(self) -> I:
        return self.certificate.seed.owner_s


@dataclass
class CertifiedAtlas:
    field_hash: str
    patches: tuple[CertifiedPatch, ...]
    common_guard_pairs: frozenset[tuple[int, int]]
    loop_cycles: tuple[tuple[int, ...], ...]
    coverage_boxes_processed: int
    coverage_zero_free: int
    coverage_guard_covered: int
    coverage_unresolved: int
    proof_records: list[dict] = field(default_factory=list)

    def pair_is_local(self, a: int, b: int) -> bool:
        key = (a, b) if a <= b else (b, a)
        return key in self.common_guard_pairs


def _box_frame_coordinates(rect: ExactRectangle, seed: GuardSeed) -> tuple[I, I]:
    q = seed.frame.norm2
    values = []
    for x in (rect.x_lo, rect.x_hi):
        for y in (rect.y_lo, rect.y_hi):
            dx, dy = x - seed.ox, y - seed.oy
            s = Fraction(seed.frame.ex * dx + seed.frame.ey * dy, q)
            v = Fraction(seed.frame.nx * dx + seed.frame.ny * dy, q)
            values.append((s, v))
    return I(min(s for s, _ in values), max(s for s, _ in values)), I(min(v for _, v in values), max(v for _, v in values))


def _box_covered_by_patch(rect: ExactRectangle, patch: CertifiedPatch) -> bool:
    s, v = _box_frame_coordinates(rect, patch.certificate.seed)
    seed = patch.certificate.seed
    return seed.owner_s.lo <= s.lo and s.hi <= seed.owner_s.hi and seed.guard_v.lo <= v.lo and v.hi <= seed.guard_v.hi


def _vector_in_guard(vector: IntervalVector2, guard: GuardCertificate) -> bool:
    seed = guard.seed
    q = seed.frame.norm2
    dx = vector.x - seed.ox
    dy = vector.y - seed.oy
    s = (dx * seed.frame.ex + dy * seed.frame.ey) / q
    v = (dx * seed.frame.nx + dy * seed.frame.ny) / q
    return seed.guard_s.lo <= s.lo and s.hi <= seed.guard_s.hi and seed.guard_v.lo <= v.lo and v.hi <= seed.guard_v.hi


def _patch_in_guard(patch: CertifiedPatch, guard: GuardCertificate) -> bool:
    image = patch.evaluator.gamma(patch.owner_s, root_steps=14)
    return _vector_in_guard(image, guard)


class AtlasBuilder:
    def __init__(self, *, max_cover_depth: int = 10, max_cover_boxes: int = 50000):
        if type(max_cover_depth) is not int or max_cover_depth < 0:
            raise ValueError("max_cover_depth must be a nonnegative builtin int")
        if type(max_cover_boxes) is not int or max_cover_boxes <= 0:
            raise ValueError("max_cover_boxes must be a positive builtin int")
        self.max_cover_depth = max_cover_depth
        self.max_cover_boxes = max_cover_boxes

    def _certify_proposals(self, field: PiecewisePolynomialField2D, proposals: Iterable[GuardProposal]) -> tuple[list[CertifiedPatch], list[dict]]:
        patches: list[CertifiedPatch] = []
        records: list[dict] = []
        for proposal in proposals:
            attempts = [proposal.seed]
            flipped_seed = GuardSeed(
                proposal.seed.guard_id + "_flip",
                proposal.seed.ox,
                proposal.seed.oy,
                proposal.seed.frame.flipped(),
                proposal.seed.guard_s,
                I(-proposal.seed.guard_v.hi, -proposal.seed.guard_v.lo),
                proposal.seed.owner_s,
            )
            attempts.append(flipped_seed)
            accepted = None
            reasons = []
            for seed in attempts:
                result = certify_guard(field, seed)
                reasons.append(result.reason)
                if result.status is Status.VALID:
                    accepted = result.data["certificate"]
                    break
            records.append({"proposal": proposal.seed.guard_id, "accepted": accepted is not None, "reasons": reasons})
            if accepted is not None:
                patches.append(CertifiedPatch(len(patches), proposal.loop_id, proposal.order, accepted, ImplicitPatchEvaluator(accepted), proposal.source))
        return patches, records

    def build(self, field: PiecewisePolynomialField2D, *, proposals: Iterable[GuardProposal] = ()) -> Result:
        validation = field.validate()
        if validation.status is not Status.VALID:
            return Result(validation.status, f"field validation did not close: {validation.reason}")
        patches, records = self._certify_proposals(field, proposals)
        if not patches:
            return Result(Status.UNKNOWN, "no certified guard proposals")

        # Exact cyclic proposal integrity. Candidate ordering is not trusted for geometry;
        # it is accepted only if every adjacent pair is jointly contained in a certified guard.
        by_loop: dict[int, list[CertifiedPatch]] = defaultdict(list)
        for patch in patches:
            by_loop[patch.loop_id].append(patch)
        loop_cycles: list[tuple[int, ...]] = []
        common: set[tuple[int, int]] = {(p.patch_id, p.patch_id) for p in patches}
        for loop_id, items in sorted(by_loop.items()):
            items.sort(key=lambda p: p.order)
            orders = [p.order for p in items]
            if orders != list(range(len(items))):
                return Result(Status.UNKNOWN, f"loop {loop_id} proposal order has gaps")
            if len(items) < 4:
                return Result(Status.UNKNOWN, f"loop {loop_id} has too few patches")
            cycle_ids = tuple(p.patch_id for p in items)
            for i, patch in enumerate(items):
                nxt = items[(i + 1) % len(items)]
                local = False
                for guard in (patch.certificate, nxt.certificate):
                    if _patch_in_guard(patch, guard) and _patch_in_guard(nxt, guard):
                        local = True
                        break
                if not local:
                    return Result(Status.UNKNOWN, f"adjacent patches {patch.patch_id}/{nxt.patch_id} lack common-guard certificate")
                common.add(tuple(sorted((patch.patch_id, nxt.patch_id))))
            loop_cycles.append(cycle_ids)

        queue: deque[tuple[ExactRectangle, int]] = deque((cell.rectangle, 0) for cell in field.cells)
        processed = zero_free = covered = unresolved = 0
        coverage_records: list[dict] = []
        while queue:
            if processed >= self.max_cover_boxes:
                unresolved += len(queue)
                return Result(Status.UNKNOWN, "atlas coverage box budget exhausted", {
                    "processed": processed, "unresolved": unresolved, "patches": len(patches)
                })
            rect, depth = queue.popleft()
            processed += 1
            interval = field.evaluate_interval_on_rectangle(rect)
            if not interval.contains_zero():
                zero_free += 1
                continue
            owners = [p.patch_id for p in patches if _box_covered_by_patch(rect, p)]
            if owners:
                covered += 1
                coverage_records.append({
                    "rect": [str(rect.x_lo), str(rect.x_hi), str(rect.y_lo), str(rect.y_hi)],
                    "owner_patch": min(owners),
                    "all_covering_patches": owners,
                })
                continue
            if depth >= self.max_cover_depth:
                unresolved += 1
                continue
            for child in rect.midpoint_split():
                queue.append((child, depth + 1))
        if unresolved:
            return Result(Status.UNKNOWN, "atlas coverage contains unresolved zero boxes", {
                "processed": processed, "unresolved": unresolved, "patches": len(patches)
            })
        atlas = CertifiedAtlas(
            field_hash=field.field_hash,
            patches=tuple(patches),
            common_guard_pairs=frozenset(common),
            loop_cycles=tuple(loop_cycles),
            coverage_boxes_processed=processed,
            coverage_zero_free=zero_free,
            coverage_guard_covered=covered,
            coverage_unresolved=0,
            proof_records=records + coverage_records,
        )
        return Result(Status.VALID, data={"atlas": atlas})
