from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction

from .implicit_guard import GuardCertificate
from .interval import RationalInterval as I


@dataclass(frozen=True, slots=True)
class IntervalVector2:
    x: I
    y: I

    def __add__(self, other: "IntervalVector2") -> "IntervalVector2":
        return IntervalVector2(self.x + other.x, self.y + other.y)

    def __sub__(self, other: "IntervalVector2") -> "IntervalVector2":
        return IntervalVector2(self.x - other.x, self.y - other.y)

    def dot(self, other: "IntervalVector2") -> I:
        return self.x * other.x + self.y * other.y

    def square_norm(self) -> I:
        return self.x.square() + self.y.square()


class ImplicitPatchEvaluator:
    def __init__(self, certificate: GuardCertificate):
        if type(certificate) is not GuardCertificate:
            raise TypeError("certificate must be GuardCertificate")
        self.certificate = certificate

    @property
    def owner_s(self) -> I:
        return self.certificate.seed.owner_s

    def root_enclosure(self, s: I, *, steps: int = 12) -> I:
        if type(s) is not I:
            raise TypeError("s must be RationalInterval")
        if not (self.certificate.seed.guard_s.lo <= s.lo <= s.hi <= self.certificate.seed.guard_s.hi):
            raise ValueError("s interval lies outside guard")
        candidates = [self.certificate.seed.guard_v]
        for _ in range(steps):
            next_candidates: list[I] = []
            for candidate in candidates:
                mid = candidate.midpoint
                for half in (I(candidate.lo, mid), I(mid, candidate.hi)):
                    if self.certificate.evaluate("f", s, half).contains_zero():
                        next_candidates.append(half)
            if not next_candidates:
                raise RuntimeError("guard certificate/root enclosure inconsistency")
            candidates = next_candidates
        return I.hull_many(candidates)

    def gamma(self, s: I, *, root_steps: int = 12) -> IntervalVector2:
        seed = self.certificate.seed
        v = self.root_enclosure(s, steps=root_steps)
        return IntervalVector2(
            I.point(seed.ox) + s * seed.frame.ex + v * seed.frame.nx,
            I.point(seed.oy) + s * seed.frame.ey + v * seed.frame.ny,
        )

    def _fprime(self, s: I, v: I) -> I:
        de = self.certificate.evaluate("s", s, v)
        dn = self.certificate.evaluate("v", s, v)
        return -de / dn

    def gamma_prime(self, s: I, *, root_steps: int = 12) -> IntervalVector2:
        seed = self.certificate.seed
        v = self.root_enclosure(s, steps=root_steps)
        fp = self._fprime(s, v)
        return IntervalVector2(
            I.point(seed.frame.ex) + fp * seed.frame.nx,
            I.point(seed.frame.ey) + fp * seed.frame.ny,
        )

    def gamma_second(self, s: I, *, root_steps: int = 12) -> IntervalVector2:
        seed = self.certificate.seed
        v = self.root_enclosure(s, steps=root_steps)
        fp = self._fprime(s, v)
        fss = self.certificate.evaluate("ss", s, v)
        fsv = self.certificate.evaluate("sv", s, v)
        fvv = self.certificate.evaluate("vv", s, v)
        fn = self.certificate.evaluate("v", s, v)
        fpp = -(fss + 2 * fsv * fp + fvv * fp.square()) / fn
        return IntervalVector2(fpp * seed.frame.nx, fpp * seed.frame.ny)
