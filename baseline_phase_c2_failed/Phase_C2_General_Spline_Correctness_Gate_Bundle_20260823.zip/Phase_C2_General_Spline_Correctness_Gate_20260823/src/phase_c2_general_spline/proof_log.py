from __future__ import annotations

from dataclasses import asdict, dataclass, field, is_dataclass
from fractions import Fraction
import hashlib
import json
from pathlib import Path
from typing import Any


def _jsonable(value: Any) -> Any:
    if type(value) is Fraction:
        return {"numerator": value.numerator, "denominator": value.denominator}
    if is_dataclass(value):
        return _jsonable(asdict(value))
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set, frozenset)):
        return [_jsonable(v) for v in value]
    if hasattr(value, "value") and type(getattr(value, "value")) is str:
        return value.value
    if value is None or type(value) in (str, int, bool):
        return value
    return repr(value)


@dataclass
class ProofStage:
    name: str
    status: str
    reason: str
    data: dict[str, Any] = field(default_factory=dict)


@dataclass
class ReachProofLog:
    engine_version: str
    field_hash: str
    r0: Fraction
    stages: list[ProofStage] = field(default_factory=list)
    final_status: str = "UNKNOWN"
    final_reason: str = ""
    log_hash: str = ""

    def add(self, name: str, status: str, reason: str = "", data: dict[str, Any] | None = None) -> None:
        self.stages.append(ProofStage(name, status, reason, data or {}))

    def payload(self, *, include_hash: bool = False) -> dict[str, Any]:
        payload = {
            "engine_version": self.engine_version,
            "field_hash": self.field_hash,
            "r0": _jsonable(self.r0),
            "stages": _jsonable(self.stages),
            "final_status": self.final_status,
            "final_reason": self.final_reason,
        }
        if include_hash:
            payload["log_hash"] = self.log_hash
        return payload

    def seal(self) -> None:
        encoded = json.dumps(self.payload(include_hash=False), sort_keys=True, separators=(",", ":")).encode()
        self.log_hash = hashlib.sha256(encoded).hexdigest()

    def write(self, path: str | Path) -> None:
        self.seal()
        Path(path).write_text(json.dumps(self.payload(include_hash=True), indent=2, sort_keys=True), encoding="utf-8")


def replay_structural_check(path: str | Path) -> tuple[bool, str]:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    saved_hash = payload.pop("log_hash", "")
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    if hashlib.sha256(encoded).hexdigest() != saved_hash:
        return False, "proof log hash mismatch"
    if payload.get("final_status") == "VALID":
        required = ["field_validation", "atlas", "delta_loc", "curvature", "dcsd"]
        stages = {item["name"]: item["status"] for item in payload.get("stages", [])}
        missing = [name for name in required if stages.get(name) != "VALID"]
        if missing:
            return False, f"VALID log has missing/nonvalid stages: {missing}"
    return True, "OK"
