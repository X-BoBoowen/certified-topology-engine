from __future__ import annotations

from fractions import Fraction
from typing import Iterable

from .curvature_certificate import certify_curvature
from .delta_loc import certify_delta_loc
from .exact_types import ExactInputError, require_fraction
from .general_pair_solver import certify_dcsd
from .proof_log import ReachProofLog
from .scenarios import GuardProposal
from .spline_atlas import AtlasBuilder
from .status import Result, Status


class GeneralReachEngine:
    VERSION = "phase-c2-0.1.0"

    def __init__(
        self,
        *,
        atlas_depth: int = 10,
        atlas_boxes: int = 50000,
        delta_depth: int = 14,
        delta_boxes: int = 500000,
        curvature_depth: int = 12,
        curvature_boxes: int = 500000,
        pair_depth: int = 18,
        pair_boxes: int = 1000000,
    ):
        values = {
            "atlas_depth": atlas_depth,
            "atlas_boxes": atlas_boxes,
            "delta_depth": delta_depth,
            "delta_boxes": delta_boxes,
            "curvature_depth": curvature_depth,
            "curvature_boxes": curvature_boxes,
            "pair_depth": pair_depth,
            "pair_boxes": pair_boxes,
        }
        for name, value in values.items():
            if type(value) is not int or value < 0 or (name.endswith("boxes") and value == 0):
                raise ValueError(f"{name} has invalid value")
        self.atlas_depth = atlas_depth
        self.atlas_boxes = atlas_boxes
        self.delta_depth = delta_depth
        self.delta_boxes = delta_boxes
        self.curvature_depth = curvature_depth
        self.curvature_boxes = curvature_boxes
        self.pair_depth = pair_depth
        self.pair_boxes = pair_boxes

    def certify(self, field, r0: Fraction | int, *, proposals: Iterable[GuardProposal] = ()) -> Result:
        try:
            radius = require_fraction(r0, "r0")
        except ExactInputError as exc:
            return Result(Status.INPUT_INVALID, str(exc))
        if radius <= 0:
            return Result(Status.INPUT_INVALID, "r0 must be positive")
        field_hash = getattr(field, "field_hash", "")
        log = ReachProofLog(self.VERSION, field_hash, radius)

        validation = field.validate()
        log.field_hash = getattr(field, "field_hash", "")
        log.add("field_validation", validation.status.value, validation.reason, validation.data)
        if validation.status is not Status.VALID:
            log.final_status = validation.status.value
            log.final_reason = validation.reason
            log.seal()
            return Result(validation.status, validation.reason, {"proof_log": log})

        atlas_result = AtlasBuilder(max_cover_depth=self.atlas_depth, max_cover_boxes=self.atlas_boxes).build(field, proposals=proposals)
        log.add("atlas", atlas_result.status.value, atlas_result.reason, {
            k: v for k, v in atlas_result.data.items() if k != "atlas"
        })
        if atlas_result.status is not Status.VALID:
            log.final_status = atlas_result.status.value
            log.final_reason = atlas_result.reason
            log.seal()
            return Result(atlas_result.status, atlas_result.reason, {"proof_log": log})
        atlas = atlas_result.data["atlas"]
        log.stages[-1].data.update({
            "patch_count": len(atlas.patches),
            "loop_count": len(atlas.loop_cycles),
            "coverage_boxes_processed": atlas.coverage_boxes_processed,
            "coverage_zero_free": atlas.coverage_zero_free,
            "coverage_guard_covered": atlas.coverage_guard_covered,
            "coverage_unresolved": atlas.coverage_unresolved,
        })

        delta_result = certify_delta_loc(atlas, max_depth=self.delta_depth, max_boxes=self.delta_boxes)
        log.add("delta_loc", delta_result.status.value, delta_result.reason, {
            k: v for k, v in delta_result.data.items() if k != "pair_certificates"
        })
        if delta_result.status is not Status.VALID:
            log.final_status = Status.UNKNOWN.value
            log.final_reason = delta_result.reason
            log.seal()
            return Result(Status.UNKNOWN, delta_result.reason, {"proof_log": log})
        delta = delta_result.data["delta_loc"]

        curvature_result = certify_curvature(atlas, radius, max_depth=self.curvature_depth, max_boxes=self.curvature_boxes)
        log.add("curvature", curvature_result.status.value, curvature_result.reason, curvature_result.data)
        if curvature_result.status is not Status.VALID:
            log.final_status = Status.UNKNOWN.value
            log.final_reason = curvature_result.reason
            log.seal()
            return Result(Status.UNKNOWN, curvature_result.reason, {"proof_log": log})

        dcsd_result = certify_dcsd(
            atlas,
            radius,
            delta_loc=delta,
            max_depth=self.pair_depth,
            max_boxes=self.pair_boxes,
        )
        log.add("dcsd", dcsd_result.status.value, dcsd_result.reason, dcsd_result.data)
        if dcsd_result.status is not Status.VALID:
            log.final_status = Status.UNKNOWN.value
            log.final_reason = dcsd_result.reason
            log.seal()
            return Result(Status.UNKNOWN, dcsd_result.reason, {"proof_log": log})

        log.final_status = Status.VALID.value
        log.final_reason = "all exact field, atlas, local, curvature, and exhaustive pair obligations closed"
        log.seal()
        return Result(Status.VALID, log.final_reason, {
            "proof_log": log,
            "atlas": atlas,
            "delta_loc": delta,
            "r0": radius,
        })
