from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class Status(str, Enum):
    VALID = "VALID"
    UNKNOWN = "UNKNOWN"
    INPUT_INVALID = "INPUT_INVALID"


@dataclass(frozen=True)
class Result:
    status: Status
    reason: str = ""
    data: dict[str, Any] = field(default_factory=dict)
