from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Iterable

from .exact_types import require_fraction


@dataclass(frozen=True, slots=True)
class RationalInterval:
    lo: Fraction
    hi: Fraction

    def __post_init__(self) -> None:
        lo = require_fraction(self.lo, "lo")
        hi = require_fraction(self.hi, "hi")
        if lo > hi:
            raise ValueError("interval lower endpoint exceeds upper endpoint")
        object.__setattr__(self, "lo", lo)
        object.__setattr__(self, "hi", hi)

    @classmethod
    def point(cls, value: Fraction | int) -> "RationalInterval":
        q = require_fraction(value, "value")
        return cls(q, q)

    @classmethod
    def hull_many(cls, intervals: Iterable["RationalInterval"]) -> "RationalInterval":
        values = list(intervals)
        if not values:
            raise ValueError("cannot hull an empty collection")
        return cls(min(x.lo for x in values), max(x.hi for x in values))

    @property
    def width(self) -> Fraction:
        return self.hi - self.lo

    @property
    def midpoint(self) -> Fraction:
        return (self.lo + self.hi) / 2

    def contains(self, value: Fraction | int) -> bool:
        q = require_fraction(value, "value")
        return self.lo <= q <= self.hi

    def contains_zero(self) -> bool:
        return self.lo <= 0 <= self.hi

    def strictly_positive(self) -> bool:
        return self.lo > 0

    def strictly_negative(self) -> bool:
        return self.hi < 0

    def abs_upper(self) -> Fraction:
        return max(abs(self.lo), abs(self.hi))

    def abs_lower(self) -> Fraction:
        if self.contains_zero():
            return Fraction(0)
        return min(abs(self.lo), abs(self.hi))

    def intersection(self, other: "RationalInterval") -> "RationalInterval | None":
        lo = max(self.lo, other.lo)
        hi = min(self.hi, other.hi)
        if lo > hi:
            return None
        return RationalInterval(lo, hi)

    def __neg__(self) -> "RationalInterval":
        return RationalInterval(-self.hi, -self.lo)

    def __add__(self, other: object) -> "RationalInterval":
        rhs = as_interval(other)
        return RationalInterval(self.lo + rhs.lo, self.hi + rhs.hi)

    __radd__ = __add__

    def __sub__(self, other: object) -> "RationalInterval":
        return self + (-as_interval(other))

    def __rsub__(self, other: object) -> "RationalInterval":
        return as_interval(other) - self

    def __mul__(self, other: object) -> "RationalInterval":
        rhs = as_interval(other)
        products = (
            self.lo * rhs.lo,
            self.lo * rhs.hi,
            self.hi * rhs.lo,
            self.hi * rhs.hi,
        )
        return RationalInterval(min(products), max(products))

    __rmul__ = __mul__

    def reciprocal(self) -> "RationalInterval":
        if self.contains_zero():
            raise ZeroDivisionError("interval contains zero")
        return RationalInterval(min(1 / self.lo, 1 / self.hi), max(1 / self.lo, 1 / self.hi))

    def __truediv__(self, other: object) -> "RationalInterval":
        return self * as_interval(other).reciprocal()

    def square(self) -> "RationalInterval":
        if self.contains_zero():
            return RationalInterval(Fraction(0), max(self.lo * self.lo, self.hi * self.hi))
        squares = (self.lo * self.lo, self.hi * self.hi)
        return RationalInterval(min(squares), max(squares))

    def pow_nonnegative(self, exponent: int) -> "RationalInterval":
        if type(exponent) is not int or exponent < 0:
            raise ValueError("exponent must be a nonnegative builtin int")
        if exponent == 0:
            return RationalInterval.point(1)
        result = RationalInterval.point(1)
        base = self
        n = exponent
        while n:
            if n & 1:
                result = result * base
            n >>= 1
            if n:
                base = base * base
        return result


def as_interval(value: object) -> RationalInterval:
    if type(value) is RationalInterval:
        return value
    return RationalInterval.point(require_fraction(value, "interval scalar"))
