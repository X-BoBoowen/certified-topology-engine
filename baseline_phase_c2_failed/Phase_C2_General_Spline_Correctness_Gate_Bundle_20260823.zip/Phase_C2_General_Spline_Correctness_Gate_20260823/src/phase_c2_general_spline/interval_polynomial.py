from .rational_polynomial import RationalPolynomial2D

__all__ = ["RationalPolynomial2D"]
