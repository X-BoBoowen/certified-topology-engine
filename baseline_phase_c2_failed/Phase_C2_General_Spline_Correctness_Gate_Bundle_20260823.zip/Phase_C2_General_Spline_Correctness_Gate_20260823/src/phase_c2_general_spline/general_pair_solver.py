from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from fractions import Fraction

from .exact_types import ExactInputError, require_fraction
from .implicit_patch import IntervalVector2
from .interval import RationalInterval as I
from .spline_atlas import CertifiedAtlas, CertifiedPatch
from .status import Result, Status


@dataclass(frozen=True)
class PairSolverLog:
    total_unordered_pairs: int
    local_pruned_pairs: int
    parameter_boxes: int
    local_distance_pruned: int
    threshold_distance_pruned: int
    g1_pruned: int
    g2_pruned: int
    unresolved: int
    max_depth_seen: int


def _split(interval: I) -> tuple[I, I]:
    mid = interval.midpoint
    return I(interval.lo, mid), I(mid, interval.hi)


def _box_quantities(a: CertifiedPatch, b: CertifiedPatch, s: I, t: I):
    ga = a.evaluator.gamma(s, root_steps=12)
    gb = b.evaluator.gamma(t, root_steps=12)
    ta = a.evaluator.gamma_prime(s, root_steps=12)
    tb = b.evaluator.gamma_prime(t, root_steps=12)
    chord = ga - gb
    return chord.square_norm(), chord.dot(ta), chord.dot(tb)


def certify_dcsd(
    atlas: CertifiedAtlas,
    r0: Fraction | int,
    *,
    delta_loc: Fraction | int,
    max_depth: int = 18,
    max_boxes: int = 1_000_000,
) -> Result:
    try:
        radius = require_fraction(r0, "r0")
        delta = require_fraction(delta_loc, "delta_loc")
    except ExactInputError as exc:
        return Result(Status.INPUT_INVALID, str(exc))
    if radius <= 0 or delta <= 0:
        return Result(Status.INPUT_INVALID, "r0 and delta_loc must be positive")
    threshold2 = (Fraction(2) * radius) ** 2
    delta2 = delta * delta
    patches = atlas.patches
    total_pairs = len(patches) * (len(patches) + 1) // 2
    local_pairs = boxes = local_distance = threshold_distance = g1_count = g2_count = unresolved = max_seen = 0
    queue = deque()
    for i, a in enumerate(patches):
        for b in patches[i:]:
            if atlas.pair_is_local(a.patch_id, b.patch_id):
                local_pairs += 1
            else:
                queue.append((a, b, a.owner_s, b.owner_s, 0))
    while queue:
        if boxes >= max_boxes:
            unresolved += len(queue)
            log = PairSolverLog(total_pairs, local_pairs, boxes, local_distance, threshold_distance, g1_count, g2_count, unresolved, max_seen)
            return Result(Status.UNKNOWN, "DCSD box budget exhausted", {"log": log})
        a, b, s, t, depth = queue.popleft()
        boxes += 1
        max_seen = max(max_seen, depth)
        d2, g1, g2 = _box_quantities(a, b, s, t)
        if d2.hi < delta2:
            local_distance += 1
            continue
        if d2.lo >= threshold2:
            threshold_distance += 1
            continue
        if not g1.contains_zero():
            g1_count += 1
            continue
        if not g2.contains_zero():
            g2_count += 1
            continue
        if depth >= max_depth:
            unresolved += 1
            continue
        if s.width >= t.width:
            left, right = _split(s)
            queue.append((a, b, left, t, depth + 1))
            queue.append((a, b, right, t, depth + 1))
        else:
            left, right = _split(t)
            queue.append((a, b, s, left, depth + 1))
            queue.append((a, b, s, right, depth + 1))
    log = PairSolverLog(total_pairs, local_pairs, boxes, local_distance, threshold_distance, g1_count, g2_count, unresolved, max_seen)
    if unresolved:
        return Result(Status.UNKNOWN, "unresolved doubly-critical parameter boxes", {"log": log})
    return Result(Status.VALID, data={"log": log, "threshold2": threshold2, "delta_loc": delta})
