from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Literal

from .cell_complex import ExactRectangle, PiecewisePolynomialField2D
from .exact_types import ExactInputError, require_fraction
from .frame_dictionary import Frame
from .interval import RationalInterval as I
from .rational_polynomial import RationalPolynomial2D as P
from .status import Result, Status


@dataclass(frozen=True, slots=True)
class GuardSeed:
    guard_id: str
    ox: Fraction
    oy: Fraction
    frame: Frame
    guard_s: I
    guard_v: I
    owner_s: I

    def __post_init__(self) -> None:
        if type(self.guard_id) is not str or not self.guard_id:
            raise ExactInputError("guard_id must be a nonempty builtin str")
        object.__setattr__(self, "ox", require_fraction(self.ox, "ox"))
        object.__setattr__(self, "oy", require_fraction(self.oy, "oy"))
        if type(self.frame) is not Frame:
            raise ExactInputError("frame must be Frame")
        for name in ("guard_s", "guard_v", "owner_s"):
            if type(getattr(self, name)) is not I:
                raise ExactInputError(f"{name} must be RationalInterval")
        if not (self.guard_s.lo < self.owner_s.lo <= self.owner_s.hi < self.guard_s.hi):
            raise ExactInputError("owner_s must be strictly contained in guard_s")

    def point(self, s: Fraction, v: Fraction) -> tuple[Fraction, Fraction]:
        return (
            self.ox + s * self.frame.ex + v * self.frame.nx,
            self.oy + s * self.frame.ey + v * self.frame.ny,
        )

    def aabb(self) -> ExactRectangle:
        corners = [self.point(s, v) for s in (self.guard_s.lo, self.guard_s.hi) for v in (self.guard_v.lo, self.guard_v.hi)]
        return ExactRectangle(
            min(x for x, _ in corners),
            max(x for x, _ in corners),
            min(y for _, y in corners),
            max(y for _, y in corners),
        )


@dataclass(frozen=True)
class GuardCertificate:
    seed: GuardSeed
    incident_cell_ids: tuple[str, ...]
    transformed_pieces: tuple[P, ...]
    normal_derivative_interval: I
    tangent_derivative_interval: I
    slope_bound: Fraction
    lower_face_interval: I
    upper_face_interval: I

    def evaluate(self, kind: Literal["f", "s", "v", "ss", "sv", "vv"], s: I, v: I) -> I:
        derivatives = {
            "f": (0, 0),
            "s": (1, 0),
            "v": (0, 1),
            "ss": (2, 0),
            "sv": (1, 1),
            "vv": (0, 2),
        }
        ds, dv = derivatives[kind]
        intervals = [p.derivative(ds, dv).evaluate_interval(s, v) for p in self.transformed_pieces]
        return I.hull_many(intervals)


def _rectangle_inside_domain(rectangle: ExactRectangle, domain: ExactRectangle) -> bool:
    return domain.contains_rectangle(rectangle)


def certify_guard(
    field: PiecewisePolynomialField2D,
    seed: GuardSeed,
    *,
    slope_limit: Fraction = Fraction(1, 2),
) -> Result:
    if not field._validated:
        validation = field.validate()
        if validation.status is not Status.VALID:
            return Result(validation.status, f"field validation failed: {validation.reason}")
    try:
        limit = require_fraction(slope_limit, "slope_limit")
        if not (0 < limit < 1):
            return Result(Status.INPUT_INVALID, "slope_limit must be in (0,1)")
        aabb = seed.aabb()
        if not _rectangle_inside_domain(aabb, field.domain):
            return Result(Status.UNKNOWN, "guard is not contained in field domain")
        cells = field.incident_cells(aabb)
        if not cells:
            return Result(Status.UNKNOWN, "guard has no incident field cells")
        transformed = tuple(
            cell.polynomial.compose_affine(
                seed.ox,
                seed.oy,
                seed.frame.ex,
                seed.frame.ey,
                seed.frame.nx,
                seed.frame.ny,
            )
            for cell in cells
        )
        dn = I.hull_many([p.dy().evaluate_interval(seed.guard_s, seed.guard_v) for p in transformed])
        de = I.hull_many([p.dx().evaluate_interval(seed.guard_s, seed.guard_v) for p in transformed])
        if not dn.strictly_positive():
            return Result(Status.UNKNOWN, "normal derivative is not certified strictly positive")
        slope = de.abs_upper() / dn.lo
        if slope > limit:
            return Result(Status.UNKNOWN, "slope certificate does not close")
        lower = I.hull_many([p.evaluate_interval(seed.guard_s, I.point(seed.guard_v.lo)) for p in transformed])
        upper = I.hull_many([p.evaluate_interval(seed.guard_s, I.point(seed.guard_v.hi)) for p in transformed])
        if not lower.strictly_negative() or not upper.strictly_positive():
            return Result(Status.UNKNOWN, "opposite normal-face signs not certified")
        certificate = GuardCertificate(
            seed=seed,
            incident_cell_ids=tuple(sorted(cell.cell_id for cell in cells)),
            transformed_pieces=transformed,
            normal_derivative_interval=dn,
            tangent_derivative_interval=de,
            slope_bound=slope,
            lower_face_interval=lower,
            upper_face_interval=upper,
        )
        return Result(Status.VALID, data={"certificate": certificate})
    except (ExactInputError, ValueError, ZeroDivisionError) as exc:
        return Result(Status.INPUT_INVALID, str(exc))
