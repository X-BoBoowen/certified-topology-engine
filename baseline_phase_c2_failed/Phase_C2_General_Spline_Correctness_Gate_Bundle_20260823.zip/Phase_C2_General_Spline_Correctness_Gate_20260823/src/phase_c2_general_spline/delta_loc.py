from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from fractions import Fraction
from math import isqrt

from .implicit_patch import IntervalVector2
from .interval import RationalInterval as I
from .spline_atlas import CertifiedAtlas, CertifiedPatch
from .status import Result, Status


def rational_sqrt_lower(value: Fraction, *, bits: int = 48) -> Fraction:
    if value < 0:
        raise ValueError("cannot take square root of a negative rational")
    if value == 0:
        return Fraction(0)
    scaled = (value.numerator << (2 * bits)) // value.denominator
    return Fraction(isqrt(scaled), 1 << bits)


@dataclass(frozen=True)
class DistanceCertificate:
    patch_a: int
    patch_b: int
    distance2_lower: Fraction
    boxes: int
    max_depth_seen: int


def _split_interval(interval: I) -> tuple[I, I]:
    mid = interval.midpoint
    return I(interval.lo, mid), I(mid, interval.hi)


def _distance2_box(a: CertifiedPatch, b: CertifiedPatch, s: I, t: I) -> I:
    ga = a.evaluator.gamma(s, root_steps=12)
    gb = b.evaluator.gamma(t, root_steps=12)
    return (ga - gb).square_norm()


def certify_patch_distance_positive(
    a: CertifiedPatch,
    b: CertifiedPatch,
    *,
    max_depth: int,
    max_boxes: int,
) -> Result:
    queue = deque([(a.owner_s, b.owner_s, 0)])
    boxes = 0
    leaves: list[Fraction] = []
    max_seen = 0
    while queue:
        if boxes >= max_boxes:
            return Result(Status.UNKNOWN, "distance box budget exhausted", {"boxes": boxes, "queued": len(queue)})
        s, t, depth = queue.popleft()
        boxes += 1
        max_seen = max(max_seen, depth)
        d2 = _distance2_box(a, b, s, t)
        if d2.lo > 0:
            leaves.append(d2.lo)
            continue
        if depth >= max_depth:
            return Result(Status.UNKNOWN, "distance lower bound did not become positive", {"boxes": boxes, "depth": depth})
        if s.width >= t.width:
            left, right = _split_interval(s)
            queue.append((left, t, depth + 1))
            queue.append((right, t, depth + 1))
        else:
            left, right = _split_interval(t)
            queue.append((s, left, depth + 1))
            queue.append((s, right, depth + 1))
    if not leaves:
        return Result(Status.UNKNOWN, "empty distance partition")
    lower = min(leaves)
    return Result(Status.VALID, data={
        "certificate": DistanceCertificate(a.patch_id, b.patch_id, lower, boxes, max_seen)
    })


def certify_delta_loc(
    atlas: CertifiedAtlas,
    *,
    max_depth: int = 14,
    max_boxes: int = 500000,
) -> Result:
    if type(atlas) is not CertifiedAtlas:
        return Result(Status.INPUT_INVALID, "atlas must be CertifiedAtlas")
    remaining_budget = max_boxes
    certificates: list[DistanceCertificate] = []
    patches = atlas.patches
    for i, a in enumerate(patches):
        for b in patches[i:]:
            if atlas.pair_is_local(a.patch_id, b.patch_id):
                continue
            if remaining_budget <= 0:
                return Result(Status.UNKNOWN, "delta_loc global box budget exhausted")
            result = certify_patch_distance_positive(
                a,
                b,
                max_depth=max_depth,
                max_boxes=remaining_budget,
            )
            if result.status is not Status.VALID:
                return Result(Status.UNKNOWN, f"delta_loc pair {a.patch_id}/{b.patch_id}: {result.reason}", result.data)
            cert = result.data["certificate"]
            certificates.append(cert)
            remaining_budget -= cert.boxes
    if not certificates:
        return Result(Status.UNKNOWN, "no certified nonlocal patch pair")
    min_d2 = min(c.distance2_lower for c in certificates)
    distance_lower = rational_sqrt_lower(min_d2)
    delta = distance_lower / 2
    if delta <= 0:
        return Result(Status.UNKNOWN, "nonpositive delta_loc lower bound")
    return Result(Status.VALID, data={
        "delta_loc": delta,
        "minimum_distance2_lower": min_d2,
        "pair_certificates": certificates,
        "boxes": max_boxes - remaining_budget,
    })
