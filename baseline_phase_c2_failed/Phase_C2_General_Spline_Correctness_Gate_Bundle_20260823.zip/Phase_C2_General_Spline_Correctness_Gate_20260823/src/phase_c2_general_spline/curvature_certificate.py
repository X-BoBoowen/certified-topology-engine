from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from fractions import Fraction

from .exact_types import ExactInputError, require_fraction
from .interval import RationalInterval as I
from .spline_atlas import CertifiedAtlas
from .status import Result, Status


@dataclass(frozen=True)
class CurvatureLog:
    parameter_boxes: int
    max_depth_seen: int
    unresolved: int


def _split(interval: I) -> tuple[I, I]:
    mid = interval.midpoint
    return I(interval.lo, mid), I(mid, interval.hi)


def certify_curvature(atlas: CertifiedAtlas, r0: Fraction | int, *, max_depth: int = 12, max_boxes: int = 500000) -> Result:
    try:
        radius = require_fraction(r0, "r0")
    except ExactInputError as exc:
        return Result(Status.INPUT_INVALID, str(exc))
    if radius <= 0:
        return Result(Status.INPUT_INVALID, "r0 must be positive")
    queue = deque((patch, patch.owner_s, 0) for patch in atlas.patches)
    boxes = unresolved = max_seen = 0
    while queue:
        if boxes >= max_boxes:
            unresolved += len(queue)
            return Result(Status.UNKNOWN, "curvature box budget exhausted", {
                "log": CurvatureLog(boxes, max_seen, unresolved)
            })
        patch, s, depth = queue.popleft()
        boxes += 1
        max_seen = max(max_seen, depth)
        tangent = patch.evaluator.gamma_prime(s, root_steps=12)
        second = patch.evaluator.gamma_second(s, root_steps=12)
        determinant = tangent.x * second.y - tangent.y * second.x
        speed2 = tangent.square_norm()
        lhs = determinant.abs_upper() ** 2 * radius * radius
        rhs = speed2.lo ** 3
        if speed2.lo > 0 and lhs <= rhs:
            continue
        if depth >= max_depth:
            unresolved += 1
            continue
        left, right = _split(s)
        queue.append((patch, left, depth + 1))
        queue.append((patch, right, depth + 1))
    log = CurvatureLog(boxes, max_seen, unresolved)
    if unresolved:
        return Result(Status.UNKNOWN, "curvature upper bound not closed", {"log": log})
    return Result(Status.VALID, data={"log": log})
