"""Phase C.2 exact-rational piecewise-polynomial reach reference engine."""
