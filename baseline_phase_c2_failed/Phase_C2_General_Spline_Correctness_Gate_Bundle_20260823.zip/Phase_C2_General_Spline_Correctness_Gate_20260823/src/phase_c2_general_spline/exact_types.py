from __future__ import annotations

from fractions import Fraction
import re
from typing import Final


class ExactInputError(TypeError):
    """Raised when an unsupported numeric object reaches the certified path."""


_DECIMAL_RE: Final[re.Pattern[str]] = re.compile(r"^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$")
_FRACTION_RE: Final[re.Pattern[str]] = re.compile(r"^[+-]?\d+/[1-9]\d*$")
_INTEGER_RE: Final[re.Pattern[str]] = re.compile(r"^[+-]?\d+$")


def require_fraction(value: object, name: str) -> Fraction:
    """Accept only builtin int (excluding bool) and exact Fraction.

    Numeric subclasses and objects implementing coercion protocols are intentionally
    rejected. This function never calls float(), int(), __index__, or as_integer_ratio.
    """
    if type(value) is Fraction:
        return value
    if type(value) is int:
        return Fraction(value, 1)
    raise ExactInputError(
        f"{name} must be a builtin int or fractions.Fraction; got {type(value).__name__}"
    )


def parse_rational(text: str) -> Fraction:
    """Explicit textual adapter; never called implicitly by certificate APIs."""
    if type(text) is not str:
        raise TypeError("parse_rational expects a builtin str")
    stripped = text.strip()
    if _FRACTION_RE.fullmatch(stripped):
        numerator, denominator = stripped.split("/", 1)
        return Fraction(int(numerator), int(denominator))
    if _INTEGER_RE.fullmatch(stripped):
        return Fraction(int(stripped), 1)
    if _DECIMAL_RE.fullmatch(stripped):
        sign = -1 if stripped.startswith("-") else 1
        unsigned = stripped.lstrip("+-")
        if "." not in unsigned:
            return Fraction(sign * int(unsigned), 1)
        whole, frac = unsigned.split(".", 1)
        if whole == "":
            whole = "0"
        denominator = 10 ** len(frac)
        numerator = int(whole) * denominator + (int(frac) if frac else 0)
        return Fraction(sign * numerator, denominator)
    raise ValueError(f"not an exact rational literal: {text!r}")
