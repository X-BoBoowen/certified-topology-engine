from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from hashlib import sha256
import json
from typing import Iterable

from .exact_types import ExactInputError, require_fraction
from .interval import RationalInterval as I
from .rational_polynomial import RationalPolynomial2D as P
from .status import Result, Status


@dataclass(frozen=True, slots=True)
class ExactRectangle:
    x_lo: Fraction
    x_hi: Fraction
    y_lo: Fraction
    y_hi: Fraction

    def __post_init__(self) -> None:
        values = [
            require_fraction(self.x_lo, "x_lo"),
            require_fraction(self.x_hi, "x_hi"),
            require_fraction(self.y_lo, "y_lo"),
            require_fraction(self.y_hi, "y_hi"),
        ]
        if values[0] >= values[1] or values[2] >= values[3]:
            raise ExactInputError("rectangle must have strictly positive side lengths")
        object.__setattr__(self, "x_lo", values[0])
        object.__setattr__(self, "x_hi", values[1])
        object.__setattr__(self, "y_lo", values[2])
        object.__setattr__(self, "y_hi", values[3])

    @property
    def x_interval(self) -> I:
        return I(self.x_lo, self.x_hi)

    @property
    def y_interval(self) -> I:
        return I(self.y_lo, self.y_hi)

    @property
    def width(self) -> Fraction:
        return self.x_hi - self.x_lo

    @property
    def height(self) -> Fraction:
        return self.y_hi - self.y_lo

    def contains_rectangle(self, other: "ExactRectangle") -> bool:
        return self.x_lo <= other.x_lo <= other.x_hi <= self.x_hi and self.y_lo <= other.y_lo <= other.y_hi <= self.y_hi

    def intersects_closed(self, other: "ExactRectangle") -> bool:
        return not (
            self.x_hi < other.x_lo
            or other.x_hi < self.x_lo
            or self.y_hi < other.y_lo
            or other.y_hi < self.y_lo
        )

    def midpoint_split(self) -> tuple["ExactRectangle", "ExactRectangle", "ExactRectangle", "ExactRectangle"]:
        # Non-dyadic-looking exact split reduces persistent alignment with simple rational extrema.
        x_mid = self.x_lo + Fraction(13, 31) * self.width
        y_mid = self.y_lo + Fraction(17, 37) * self.height
        return (
            ExactRectangle(self.x_lo, x_mid, self.y_lo, y_mid),
            ExactRectangle(x_mid, self.x_hi, self.y_lo, y_mid),
            ExactRectangle(self.x_lo, x_mid, y_mid, self.y_hi),
            ExactRectangle(x_mid, self.x_hi, y_mid, self.y_hi),
        )


@dataclass(frozen=True)
class Cell:
    cell_id: str
    rectangle: ExactRectangle
    polynomial: P

    def __post_init__(self) -> None:
        if type(self.cell_id) is not str or not self.cell_id:
            raise ExactInputError("cell_id must be a nonempty builtin str")
        if type(self.rectangle) is not ExactRectangle:
            raise ExactInputError("rectangle must be ExactRectangle")
        if type(self.polynomial) is not P:
            raise ExactInputError("polynomial must be RationalPolynomial2D")


class PiecewisePolynomialField2D:
    def __init__(self, domain: ExactRectangle, cells: Iterable[Cell]):
        if type(domain) is not ExactRectangle:
            raise ExactInputError("domain must be ExactRectangle")
        self.domain = domain
        self.cells = list(cells)
        self.cell_by_id: dict[str, Cell] = {}
        self.adjacency: dict[str, set[str]] = {}
        self._validated = False
        self.field_hash = ""

    def _edge_identity(self, a: P, b: P, *, vertical: bool, coordinate: Fraction) -> bool:
        diff = a - b
        derivatives = [
            diff,
            diff.dx(),
            diff.dy(),
            diff.derivative(2, 0),
            diff.derivative(1, 1),
            diff.derivative(0, 2),
        ]
        for polynomial in derivatives:
            restricted = polynomial.restrict_x(coordinate) if vertical else polynomial.restrict_y(coordinate)
            if restricted:
                return False
        return True

    def _boundary_zero_free(self) -> bool:
        for cell in self.cells:
            r = cell.rectangle
            p = cell.polynomial
            if r.x_lo == self.domain.x_lo:
                if p.evaluate_interval(I.point(r.x_lo), r.y_interval).contains_zero():
                    return False
            if r.x_hi == self.domain.x_hi:
                if p.evaluate_interval(I.point(r.x_hi), r.y_interval).contains_zero():
                    return False
            if r.y_lo == self.domain.y_lo:
                if p.evaluate_interval(r.x_interval, I.point(r.y_lo)).contains_zero():
                    return False
            if r.y_hi == self.domain.y_hi:
                if p.evaluate_interval(r.x_interval, I.point(r.y_hi)).contains_zero():
                    return False
        return True

    def validate(self) -> Result:
        try:
            if not self.cells:
                return Result(Status.INPUT_INVALID, "empty cell complex")
            ids = [c.cell_id for c in self.cells]
            if len(set(ids)) != len(ids):
                return Result(Status.INPUT_INVALID, "duplicate cell_id")
            if any(not self.domain.contains_rectangle(c.rectangle) for c in self.cells):
                return Result(Status.INPUT_INVALID, "cell outside domain")

            xs = sorted({self.domain.x_lo, self.domain.x_hi, *(v for c in self.cells for v in (c.rectangle.x_lo, c.rectangle.x_hi))})
            ys = sorted({self.domain.y_lo, self.domain.y_hi, *(v for c in self.cells for v in (c.rectangle.y_lo, c.rectangle.y_hi))})
            elementary: dict[tuple[Fraction, Fraction, Fraction, Fraction], list[Cell]] = {}
            for i in range(len(xs) - 1):
                for j in range(len(ys) - 1):
                    key = (xs[i], xs[i + 1], ys[j], ys[j + 1])
                    owners = [
                        c
                        for c in self.cells
                        if c.rectangle.x_lo <= xs[i]
                        and xs[i + 1] <= c.rectangle.x_hi
                        and c.rectangle.y_lo <= ys[j]
                        and ys[j + 1] <= c.rectangle.y_hi
                    ]
                    elementary[key] = owners
                    if len(owners) != 1:
                        reason = "gap" if len(owners) == 0 else "overlap"
                        return Result(Status.INPUT_INVALID, f"cell complex {reason} at {key}")

            # Require cells themselves to be elementary rectangles. This makes incidence exact and auditable.
            elementary_keys = set(elementary)
            for cell in self.cells:
                key = (cell.rectangle.x_lo, cell.rectangle.x_hi, cell.rectangle.y_lo, cell.rectangle.y_hi)
                if key not in elementary_keys:
                    return Result(Status.INPUT_INVALID, "cells must be elementary rectangles of the induced grid")

            self.cell_by_id = {c.cell_id: c for c in self.cells}
            self.adjacency = {c.cell_id: set() for c in self.cells}
            for i, a in enumerate(self.cells):
                for b in self.cells[i + 1 :]:
                    ar, br = a.rectangle, b.rectangle
                    if ar.x_hi == br.x_lo or br.x_hi == ar.x_lo:
                        overlap_lo = max(ar.y_lo, br.y_lo)
                        overlap_hi = min(ar.y_hi, br.y_hi)
                        if overlap_lo < overlap_hi:
                            coordinate = ar.x_hi if ar.x_hi == br.x_lo else br.x_hi
                            if not self._edge_identity(a.polynomial, b.polynomial, vertical=True, coordinate=coordinate):
                                return Result(Status.INPUT_INVALID, f"C2 mismatch across vertical edge {a.cell_id}/{b.cell_id}")
                            self.adjacency[a.cell_id].add(b.cell_id)
                            self.adjacency[b.cell_id].add(a.cell_id)
                    if ar.y_hi == br.y_lo or br.y_hi == ar.y_lo:
                        overlap_lo = max(ar.x_lo, br.x_lo)
                        overlap_hi = min(ar.x_hi, br.x_hi)
                        if overlap_lo < overlap_hi:
                            coordinate = ar.y_hi if ar.y_hi == br.y_lo else br.y_hi
                            if not self._edge_identity(a.polynomial, b.polynomial, vertical=False, coordinate=coordinate):
                                return Result(Status.INPUT_INVALID, f"C2 mismatch across horizontal edge {a.cell_id}/{b.cell_id}")
                            self.adjacency[a.cell_id].add(b.cell_id)
                            self.adjacency[b.cell_id].add(a.cell_id)

            if not self._boundary_zero_free():
                return Result(Status.UNKNOWN, "zero-free domain boundary not certified by exact interval enclosure")

            payload = {
                "domain": [str(self.domain.x_lo), str(self.domain.x_hi), str(self.domain.y_lo), str(self.domain.y_hi)],
                "cells": [
                    {
                        "id": c.cell_id,
                        "rect": [str(c.rectangle.x_lo), str(c.rectangle.x_hi), str(c.rectangle.y_lo), str(c.rectangle.y_hi)],
                        "coeff": sorted((i, j, str(v)) for (i, j), v in c.polynomial.coefficients.items()),
                    }
                    for c in sorted(self.cells, key=lambda item: item.cell_id)
                ],
            }
            self.field_hash = sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
            self._validated = True
            return Result(Status.VALID, data={"field_hash": self.field_hash})
        except (ExactInputError, ValueError) as exc:
            return Result(Status.INPUT_INVALID, str(exc))

    def incident_cells(self, rectangle: ExactRectangle) -> list[Cell]:
        return [c for c in self.cells if c.rectangle.intersects_closed(rectangle)]

    def cell_containing_open_point(self, x: Fraction, y: Fraction) -> Cell | None:
        matches = [c for c in self.cells if c.rectangle.x_lo < x < c.rectangle.x_hi and c.rectangle.y_lo < y < c.rectangle.y_hi]
        return matches[0] if len(matches) == 1 else None

    def evaluate_interval_on_rectangle(self, rectangle: ExactRectangle) -> I:
        intervals: list[I] = []
        for cell in self.incident_cells(rectangle):
            x = I(max(rectangle.x_lo, cell.rectangle.x_lo), min(rectangle.x_hi, cell.rectangle.x_hi))
            y = I(max(rectangle.y_lo, cell.rectangle.y_lo), min(rectangle.y_hi, cell.rectangle.y_hi))
            intervals.append(cell.polynomial.evaluate_interval(x, y))
        if not intervals:
            raise ValueError("rectangle does not intersect field domain")
        return I.hull_many(intervals)
