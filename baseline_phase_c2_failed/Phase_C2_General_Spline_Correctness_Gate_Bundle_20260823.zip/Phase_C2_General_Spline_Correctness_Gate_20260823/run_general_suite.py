from __future__ import annotations
import json
from pathlib import Path

from phase_c2_general_spline.reference_suites import run_knot_suite
from phase_c2_general_spline.suite_support import run_c1_differential

ROOT = Path(__file__).resolve().parent
proof = ROOT / "proof_logs"
differential = run_c1_differential(ROOT / "results" / "c1_captured_calls.json", proof / "circle_differential")
knot = run_knot_suite(proof / "knot_suite")
output = {"circle_differential": differential, "knot_suite": knot}
(ROOT / "results" / "general_suite_results.json").write_text(json.dumps(output, indent=2, sort_keys=True), encoding="utf-8")
print(json.dumps({
    "circle_scenarios": differential["scenario_count"],
    "circle_valid": differential["general_valid_count"],
    "circle_false_valid": differential["false_valid_count"],
    "knot_scenarios": knot["scenario_count"],
    "knot_failures": knot["failure_count"],
}, indent=2))
if differential["false_valid_count"] or knot["failure_count"]:
    raise SystemExit(1)
