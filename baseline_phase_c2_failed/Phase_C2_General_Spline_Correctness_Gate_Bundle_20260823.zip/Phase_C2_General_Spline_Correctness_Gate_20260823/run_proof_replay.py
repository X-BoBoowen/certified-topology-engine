from __future__ import annotations
import json
from pathlib import Path

from phase_c2_general_spline.proof_log import replay_structural_check

ROOT = Path(__file__).resolve().parent
rows = []
for path in sorted((ROOT / "proof_logs").rglob("*.json")):
    ok, reason = replay_structural_check(path)
    rows.append({"path": str(path.relative_to(ROOT)), "ok": ok, "reason": reason})
result = {"count": len(rows), "failures": sum(not row["ok"] for row in rows), "rows": rows}
(ROOT / "results" / "proof_replay_results.json").write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
print(json.dumps({"count": result["count"], "failures": result["failures"]}, indent=2))
if not rows or result["failures"]:
    raise SystemExit(1)
