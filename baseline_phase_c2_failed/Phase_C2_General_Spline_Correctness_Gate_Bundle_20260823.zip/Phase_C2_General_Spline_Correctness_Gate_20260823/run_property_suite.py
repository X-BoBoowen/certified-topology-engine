from __future__ import annotations
from fractions import Fraction as F
import json
import random
from pathlib import Path

from phase_c2_general_spline.cell_complex import Cell, ExactRectangle, PiecewisePolynomialField2D
from phase_c2_general_spline.frame_dictionary import Frame
from phase_c2_general_spline.implicit_guard import GuardSeed, certify_guard
from phase_c2_general_spline.implicit_patch import ImplicitPatchEvaluator
from phase_c2_general_spline.interval import RationalInterval as I
from phase_c2_general_spline.rational_polynomial import RationalPolynomial2D as P
from phase_c2_general_spline.status import Status

ROOT = Path(__file__).resolve().parent
rng = random.Random(20260823)
checks = 0
failures = []
category = {"polynomial": 0, "derivatives": 0, "implicit_patch": 0, "pair_quantities": 0, "subdivision": 0}

def check(condition, name, payload=None):
    global checks
    checks += 1
    category[name] += 1
    if not condition and not failures:
        failures.append({"check": checks, "category": name, "payload": payload})

# 30,000 exact polynomial interval checks.
for case in range(30000):
    coeff = {}
    for i in range(4):
        for j in range(4 - i):
            value = F(rng.randint(-7, 7), rng.randint(1, 9))
            if value:
                coeff[(i, j)] = value
    p = P(coeff)
    x0 = F(rng.randint(-20, 19), 10)
    x1 = x0 + F(rng.randint(1, 10), 10)
    y0 = F(rng.randint(-20, 19), 10)
    y1 = y0 + F(rng.randint(1, 10), 10)
    x = x0 + F(rng.randint(0, 10), 10) * (x1 - x0)
    y = y0 + F(rng.randint(0, 10), 10) * (y1 - y0)
    interval = p.evaluate_interval(I(x0, x1), I(y0, y1))
    check(interval.contains(p.evaluate(x, y)), "polynomial", {"case": case})

# 60,000 first/second derivative inclusion checks.
for case in range(20000):
    p = P({
        (3,0):F(rng.randint(-5,5),7),
        (2,1):F(rng.randint(-5,5),7),
        (1,2):F(rng.randint(-5,5),7),
        (0,3):F(rng.randint(-5,5),7),
        (1,0):F(rng.randint(-5,5),7),
        (0,1):F(rng.randint(-5,5),7),
    })
    x0, x1 = F(-3,2), F(5,4)
    y0, y1 = F(-4,3), F(7,5)
    x = x0 + F(rng.randint(0,100),100)*(x1-x0)
    y = y0 + F(rng.randint(0,100),100)*(y1-y0)
    X, Y = I(x0,x1), I(y0,y1)
    for derivative in (p.dx(), p.dy(), p.derivative(1,1)):
        check(derivative.evaluate_interval(X,Y).contains(derivative.evaluate(x,y)), "derivatives", {"case":case})

# Build an exact implicit unit-circle patch around (1,0).
circle = P({(2,0):F(1),(0,2):F(1),(0,0):F(-1)})
domain = ExactRectangle(F(-2),F(2),F(-2),F(2))
field = PiecewisePolynomialField2D(domain,[Cell("all",domain,circle)])
assert field.validate().status is Status.VALID
seed = GuardSeed("right",F(1),F(0),Frame.from_normal(1,0),I(F(-1,4),F(1,4)),I(F(-1,2),F(1,2)),I(F(-1,8),F(1,8)))
cert = certify_guard(field,seed).data["certificate"]
patch = ImplicitPatchEvaluator(cert)

# 6,000 implicit-root/position/derivative checks.
for case in range(1000):
    t = F(rng.randint(0,100),1000)
    den = 1+t*t
    x = (1-t*t)/den
    y = 2*t/den
    v = x-1
    S=I.point(y)
    root=patch.root_enclosure(S,steps=18)
    gamma=patch.gamma(S,root_steps=18)
    tangent=patch.gamma_prime(S,root_steps=18)
    second=patch.gamma_second(S,root_steps=18)
    fp=-y/x
    fpp=-1/(x*x*x)
    check(root.contains(v),"implicit_patch",{"case":case,"kind":"root"})
    check(gamma.x.contains(x),"implicit_patch",{"case":case,"kind":"x"})
    check(gamma.y.contains(y),"implicit_patch",{"case":case,"kind":"y"})
    check(tangent.x.contains(fp),"implicit_patch",{"case":case,"kind":"dxds"})
    check(tangent.y.contains(F(1)),"implicit_patch",{"case":case,"kind":"dyds"})
    check(second.x.contains(fpp),"implicit_patch",{"case":case,"kind":"second"})

# 4,500 d²/G1/G2 interval checks on exact rational curve points.
for case in range(1500):
    t1=F(rng.randint(0,100),1000)
    t2=F(rng.randint(0,100),1000)
    def point(t):
        den=1+t*t
        x=(1-t*t)/den; y=2*t/den
        fp=-y/x
        return x,y,fp
    x1,y1,fp1=point(t1); x2,y2,fp2=point(t2)
    s1,s2=I.point(y1),I.point(y2)
    g1=patch.gamma(s1,root_steps=18); g2=patch.gamma(s2,root_steps=18)
    q1=patch.gamma_prime(s1,root_steps=18); q2=patch.gamma_prime(s2,root_steps=18)
    chord=g1-g2
    dx=x1-x2; dy=y1-y2
    check(chord.square_norm().contains(dx*dx+dy*dy),"pair_quantities",{"case":case,"kind":"d2"})
    check(chord.dot(q1).contains(dx*fp1+dy),"pair_quantities",{"case":case,"kind":"g1"})
    check(chord.dot(q2).contains(dx*fp2+dy),"pair_quantities",{"case":case,"kind":"g2"})

# 1,000 cover-preserving exact bisection checks (4 checks each).
for case in range(1000):
    lo=F(rng.randint(-100,0),17); hi=lo+F(rng.randint(1,100),19)
    interval=I(lo,hi); mid=interval.midpoint
    left,right=I(lo,mid),I(mid,hi)
    check(left.lo==interval.lo,"subdivision",{"case":case})
    check(right.hi==interval.hi,"subdivision",{"case":case})
    check(left.hi==right.lo,"subdivision",{"case":case})
    check(left.lo<=mid<=right.hi,"subdivision",{"case":case})

result={"checks":checks,"category_checks":category,"failures":failures}
(ROOT/"results"/"property_results.json").write_text(json.dumps(result,indent=2,sort_keys=True),encoding="utf-8")
print(json.dumps(result,indent=2))
if failures or checks < 100000:
    raise SystemExit(1)
