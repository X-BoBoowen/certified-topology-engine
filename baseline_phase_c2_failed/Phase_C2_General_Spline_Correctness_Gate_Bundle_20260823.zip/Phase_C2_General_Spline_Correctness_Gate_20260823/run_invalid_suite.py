from __future__ import annotations
from decimal import Decimal
from fractions import Fraction as F
import json
from pathlib import Path

from phase_c2_general_spline.cell_complex import Cell, ExactRectangle, PiecewisePolynomialField2D
from phase_c2_general_spline.general_reach_engine import GeneralReachEngine
from phase_c2_general_spline.rational_polynomial import RationalPolynomial2D as P
from phase_c2_general_spline.scenarios import CircleSpec, circle_product_field, circle_proposals
from phase_c2_general_spline.status import Status

ROOT = Path(__file__).resolve().parent
rows = []

def record(name, status, expected_not_valid=True, reason=""):
    passed = status != "VALID" if expected_not_valid else status == "VALID"
    rows.append({"name": name, "status": status, "reason": reason, "passed": passed})

# Singular and crossing fields.
domain = ExactRectangle(F(-2), F(2), F(-2), F(2))
g = P({(2,0):F(1),(0,2):F(1),(0,0):F(-1)})
for name, poly in [("squared_circle", g*g), ("crossing_xy", P({(1,1):F(1)}))]:
    field = PiecewisePolynomialField2D(domain, [Cell("all", domain, poly)])
    result = GeneralReachEngine().certify(field, F(1,2), proposals=())
    record(name, result.status.value, reason=result.reason)

# Boundary contact.
field = PiecewisePolynomialField2D(domain, [Cell("all", domain, P({(1,0):F(1),(0,0):F(-2)}))])
validation = field.validate()
record("boundary_zero", validation.status.value, reason=validation.reason)

# C2 mismatch.
left = g
right = g + P({(1,0):F(1)})
field = PiecewisePolynomialField2D(domain, [
    Cell("L", ExactRectangle(F(-2),F(0),F(-2),F(2)), left),
    Cell("R", ExactRectangle(F(0),F(2),F(-2),F(2)), right),
])
validation = field.validate()
record("c2_mismatch", validation.status.value, reason=validation.reason)

# Exact numeric rejection is exercised by constructors and engine.
circles = [CircleSpec(F(0),F(0),F(2))]
field = circle_product_field(circles, F(4))
result = GeneralReachEngine().certify(field, 1.0, proposals=circle_proposals(circles))
record("float_r0", result.status.value, reason=result.reason)
for name, callable_ in [
    ("float_coefficient", lambda: P({(0,0):0.1})),
    ("decimal_coefficient", lambda: P({(0,0):Decimal("0.1")})),
    ("bool_coefficient", lambda: P({(0,0):True})),
]:
    try:
        callable_()
        record(name, "ACCEPTED", reason="constructor unexpectedly accepted unsupported type")
    except Exception as exc:
        record(name, "INPUT_INVALID", reason=str(exc))

result = {"scenario_count": len(rows), "failure_count": sum(not row["passed"] for row in rows), "rows": rows}
(ROOT / "results" / "invalid_suite_results.json").write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
print(json.dumps(result, indent=2))
if result["failure_count"]:
    raise SystemExit(1)
